import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { detectLang, LANG, tr, td } from "../i18n.js";
/**
 * Format search results into human-readable lines with bucket info
 * and operation hints for subsequent actions.
 */
function formatSearchResults(results, total, lang) {
    if (total === 0) {
        return tr("catalog_no_results", lang);
    }
    const lines = [
        `=== ${tr("catalog_search_results", lang).replace("{n}", String(total))} ===`,
        "",
    ];
    for (let i = 0; i < results.length; i++) {
        const r = results[i];
        const src = r.source || {};
        const objectName = src._object_name ?? src.object_name ?? src.name ?? "N/A";
        const bucketId = src.bucket_id ?? src._bucket_id ?? "N/A";
        const objectType = src._object_type ?? src.object_type ?? "";
        const contentType = src._content_type ?? src.content_type ?? "";
        const size = src._size ?? src.size;
        const writeTime = src._write_time ?? src.write_time ?? src.last_modified ?? "";
        const tags = src.tags ?? src._tags;
        lines.push(`  #${i + 1}  (${tr("catalog_score", lang)}: ${r.score?.toFixed(2) ?? "N/A"})`);
        lines.push(`    ${tr("catalog_object_name", lang)}: ${objectName}`);
        lines.push(`    ${tr("catalog_bucket_id", lang)}: ${bucketId}`);
        if (objectType)
            lines.push(`    ${tr("catalog_object_type", lang)}: ${objectType}`);
        if (contentType)
            lines.push(`    ${tr("catalog_content_type", lang)}: ${contentType}`);
        if (size !== undefined && size !== null) {
            lines.push(`    ${tr("catalog_size", lang)}: ${formatSizeValue(Number(size), lang)}`);
        }
        if (writeTime)
            lines.push(`    ${tr("catalog_last_modified", lang)}: ${writeTime}`);
        if (tags && Array.isArray(tags) && tags.length > 0) {
            const tagStr = tags.map((t) => `${t.key ?? t.Key}:${t.value ?? t.Value}`).join(", ");
            lines.push(`    ${tr("catalog_tags", lang)}: ${tagStr}`);
        }
        else if (tags && typeof tags === "object" && !Array.isArray(tags)) {
            const tagStr = Object.entries(tags).map(([k, v]) => `${k}:${v}`).join(", ");
            lines.push(`    ${tr("catalog_tags", lang)}: ${tagStr}`);
        }
        lines.push("");
        // Add operation hints for the first result only (or all if few results)
        if (i === 0 && total > 0) {
            const encodedName = encodeURIComponent(objectName);
            lines.push(`---`);
            lines.push(`${tr("catalog_operation_hint", lang)}:`);
            lines.push(`  - ${tr("catalog_download_hint", lang)}: bucket_id=${bucketId}  key="${objectName}"`);
            lines.push(`  - ${tr("catalog_delete_hint", lang)}: bucketId=${bucketId}  objectName="${encodedName}"`);
            lines.push(`  - ${tr("catalog_detail_hint", lang)}: storefs_catalog_get_object_metadata  bucket_id=${bucketId}  object_name="${encodedName}"`);
            lines.push(`  - ${tr("catalog_bucket_info_hint", lang)}: storefs_get_bucket  bucketId=${bucketId}`);
            lines.push("");
        }
    }
    return lines.join("\n");
}
function formatSizeValue(bytes, lang) {
    if (bytes >= 1e9)
        return (bytes / 1e9).toFixed(2) + " GB";
    if (bytes >= 1e6)
        return (bytes / 1e6).toFixed(2) + " MB";
    if (bytes >= 1e3)
        return (bytes / 1e3).toFixed(2) + " KB";
    return bytes + " B";
}
export function registerCatalogTools(server) {
    // ---- Catalog Stats ----
    server.tool("storefs_catalog_stats", td("storefs_catalog_stats"), {}, async () => {
        try {
            const data = await AdminClient.getCatalogStats();
            const lang = LANG;
            const lines = [
                `=== ${tr("catalog_stats_title", lang)} ===`,
                `${tr("catalog_enabled", lang)}: ${data.enabled ? "✅" : "❌"} ${data.enabled ? tr("catalog_enabled", lang) : tr("catalog_disabled", lang)}`,
            ];
            if (data.enabled && data.opensearch) {
                lines.push(`  ${tr("catalog_endpoint", lang)}: ${data.opensearch.endpoint}`);
                lines.push(`  ${tr("catalog_index_objects", lang)}: ${data.opensearch.index_objects}`);
                lines.push(`  ${tr("catalog_index_entities", lang)}: ${data.opensearch.index_entities}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Enable Catalog ----
    server.tool("storefs_catalog_enable", td("storefs_catalog_enable"), {}, async () => {
        try {
            await AdminClient.enableCatalog();
            const lang = LANG;
            return { content: [{ type: "text", text: tr("catalog_enable_success", lang) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Disable Catalog ----
    server.tool("storefs_catalog_disable", td("storefs_catalog_disable"), {}, async () => {
        try {
            await AdminClient.disableCatalog();
            const lang = LANG;
            return { content: [{ type: "text", text: tr("catalog_disable_success", lang) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update Catalog Config ----
    server.tool("storefs_catalog_config", td("storefs_catalog_config"), {
        endpoint: z.string().optional().describe(td("storefs_catalog_config__endpoint")),
        username: z.string().optional().describe(td("storefs_catalog_config__username")),
        password: z.string().optional().describe(td("storefs_catalog_config__password")),
        index_objects: z.string().optional().describe(td("storefs_catalog_config__index_objects")),
        index_entities: z.string().optional().describe(td("storefs_catalog_config__index_entities")),
        enabled: z.boolean().optional().describe(td("storefs_catalog_config__enabled")),
    }, async ({ endpoint, username, password, index_objects, index_entities, enabled }) => {
        detectLang({ endpoint, username });
        const lang = LANG;
        try {
            const body = {};
            if (enabled !== undefined)
                body.enabled = enabled;
            if (endpoint || username || password || index_objects || index_entities) {
                body.opensearch = {};
                if (endpoint)
                    body.opensearch.endpoint = endpoint;
                if (username)
                    body.opensearch.username = username;
                if (password)
                    body.opensearch.password = password;
                if (index_objects)
                    body.opensearch.index_objects = index_objects;
                if (index_entities)
                    body.opensearch.index_entities = index_entities;
            }
            await AdminClient.updateCatalogConfig(body);
            return { content: [{ type: "text", text: `✅ ${tr("catalog_config_updated", lang)}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Catalog Config (NEW) ----
    server.tool("storefs_catalog_get_config", td("storefs_catalog_get_config"), {}, async () => {
        try {
            const data = await AdminClient.getCatalogConfig();
            const lang = LANG;
            const lines = [
                `=== ${tr("catalog_config_title", lang)} ===`,
                "",
                `${tr("catalog_enabled", lang)}: ${data.enabled ? "✅ " + tr("catalog_enabled", lang) : "❌ " + tr("catalog_disabled", lang)}`,
                "",
                `--- ${tr("catalog_opensearch_config", lang)} ---`,
                `  ${tr("catalog_endpoint", lang)}: ${data.opensearch.endpoint}`,
                `  ${tr("catalog_username", lang)}: ${data.opensearch.username}`,
                `  ${tr("catalog_password_set", lang)}: ${data.opensearch.password ? "✅" : "❌"}`,
                `  ${tr("catalog_index_objects", lang)}: ${data.opensearch.index_objects}`,
                `  ${tr("catalog_index_entities", lang)}: ${data.opensearch.index_entities}`,
                "",
                `--- ${tr("catalog_embedding_config", lang)} ---`,
                `  ${tr("catalog_embedding_enabled", lang)}: ${data.embedding.enabled ? "✅" : "❌"}`,
                `  ${tr("catalog_embedding_base_url", lang)}: ${data.embedding.base_url}`,
                `  ${tr("catalog_embedding_model", lang)}: ${data.embedding.model}`,
                `  ${tr("catalog_embedding_dimensions", lang)}: ${data.embedding.dimensions}`,
                `  ${tr("catalog_max_chunks", lang)}: ${data.embedding.max_chunks}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Search Objects ----
    server.tool("storefs_catalog_search_objects", td("storefs_catalog_search_objects"), {
        query: z.string().optional().describe(td("storefs_catalog_search_objects__query")),
        object_type: z.string().optional().describe(td("storefs_catalog_search_objects__object_type")),
        content_type: z.string().optional().describe(td("storefs_catalog_search_objects__content_type")), // NEW
        tags: z.string().optional().describe(td("storefs_catalog_search_objects__tags")),
        meta: z.string().optional().describe(td("storefs_catalog_search_objects__meta")), // NEW
        prefix: z.string().optional().describe(td("storefs_catalog_search_objects__prefix")),
        bucket_ids: z.string().optional().describe(td("storefs_catalog_search_objects__bucket_ids")),
        size_min: z.number().optional().describe(td("storefs_catalog_search_objects__size_min")),
        size_max: z.number().optional().describe(td("storefs_catalog_search_objects__size_max")),
        time_from: z.string().optional().describe(td("storefs_catalog_search_objects__time_from")), // NEW
        time_to: z.string().optional().describe(td("storefs_catalog_search_objects__time_to")), // NEW
        limit: z.number().optional().describe(td("storefs_catalog_search_objects__limit")), // NEW
        from: z.number().optional().describe(td("storefs_catalog_search_objects__from")), // NEW
    }, async ({ query, object_type, content_type, tags, meta, prefix, bucket_ids, size_min, size_max, time_from, time_to, limit, from }) => {
        detectLang({ query, tags, prefix });
        const lang = LANG;
        try {
            const params = {};
            if (query)
                params.query = query;
            if (object_type)
                params.object_type = object_type;
            if (content_type)
                params.content_type = content_type;
            if (tags)
                params.tags = tags;
            if (meta)
                params.meta = meta;
            if (prefix)
                params.prefix = prefix;
            if (bucket_ids)
                params.bucket_ids = bucket_ids;
            if (size_min !== undefined)
                params.size_min = size_min;
            if (size_max !== undefined)
                params.size_max = size_max;
            if (time_from)
                params.time_from = time_from;
            if (time_to)
                params.time_to = time_to;
            if (limit !== undefined)
                params.limit = limit;
            if (from !== undefined)
                params.from = from;
            const data = await AdminClient.searchObjects(params);
            const formatted = formatSearchResults(data.results, data.total, lang);
            return { content: [{ type: "text", text: formatted }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- SQL Search ----
    server.tool("storefs_catalog_search", td("storefs_catalog_search"), {
        query: z.string().describe(td("storefs_catalog_search__query")),
    }, async ({ query }) => {
        detectLang({ query });
        const lang = LANG;
        try {
            const data = await AdminClient.searchBySQL(query);
            const formatted = formatSearchResults(data.results, data.total, lang);
            return { content: [{ type: "text", text: formatted }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Vector Search ----
    server.tool("storefs_catalog_vector_search", td("storefs_catalog_vector_search"), {
        vector: z.array(z.number()).optional().describe(td("storefs_catalog_vector_search__vector")),
        text: z.string().optional().describe(td("storefs_catalog_vector_search__text")),
        k: z.number().optional().describe(td("storefs_catalog_vector_search__k")),
        bucket_ids: z.array(z.number()).optional().describe(td("storefs_catalog_vector_search__bucket_ids")),
        object_type: z.string().optional().describe(td("storefs_catalog_vector_search__object_type")),
    }, async ({ vector, text, k, bucket_ids, object_type }) => {
        detectLang({ text, object_type });
        const lang = LANG;
        try {
            const body = {};
            if (vector)
                body.vector = vector;
            if (text)
                body.text = text;
            if (k)
                body.k = k;
            if (bucket_ids)
                body.bucket_ids = bucket_ids;
            if (object_type)
                body.object_type = object_type;
            const data = await AdminClient.vectorSearch(body);
            const formatted = formatSearchResults(data.results, data.total, lang);
            return { content: [{ type: "text", text: formatted }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Object Metadata ----
    server.tool("storefs_catalog_get_object_metadata", td("storefs_catalog_get_object_metadata"), {
        bucket_id: z.number().describe(td("storefs_catalog_get_object_metadata__bucket_id")),
        object_name: z.string().describe(td("storefs_catalog_get_object_metadata__object_name")),
        version: z.string().optional().describe(td("storefs_catalog_get_object_metadata__version")),
    }, async ({ bucket_id, object_name, version }) => {
        detectLang({ object_name });
        const lang = LANG;
        try {
            const data = await AdminClient.getObjectDetail(bucket_id, object_name, version);
            const lines = [
                `=== ${tr("catalog_object_detail_title", lang)} ===`,
                `  ${tr("catalog_object_name", lang)}: ${data.object_name}`,
                `  ${tr("catalog_bucket_id", lang)}: ${data.bucket_id}`,
                `  ${tr("catalog_version", lang)}: ${data.version || "N/A"}`,
                "",
                `--- ${tr("catalog_user_meta", lang)} ---`,
            ];
            if (data.user_meta && Object.keys(data.user_meta).length > 0) {
                for (const [k, v] of Object.entries(data.user_meta)) {
                    lines.push(`  ${k}: ${v}`);
                }
            }
            else {
                lines.push(`  ${tr("catalog_no_meta", lang)}`);
            }
            if (data.http_meta) {
                lines.push("", `--- ${tr("catalog_http_meta", lang)} ---`);
                for (const [k, v] of Object.entries(data.http_meta)) {
                    lines.push(`  ${k}: ${v}`);
                }
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Test Connection (NEW) ----
    server.tool("storefs_catalog_test_connection", td("storefs_catalog_test_connection"), {}, async () => {
        try {
            const data = await AdminClient.testCatalogConnection();
            const lang = LANG;
            if (data.success) {
                const lines = [
                    `✅ ${tr("catalog_test_connection_success", lang)}`,
                    `  ${tr("catalog_cluster_name", lang)}: ${data.cluster_name || "N/A"}`,
                    `  ${tr("catalog_cluster_health", lang)}: ${data.status || "N/A"}`,
                    `  ${tr("catalog_version_label", lang)}: ${data.version || "N/A"}`,
                    `  ${tr("catalog_endpoint", lang)}: ${data.endpoint || "N/A"}`,
                ];
                return { content: [{ type: "text", text: lines.join("\n") }] };
            }
            return { content: [{ type: "text", text: `❌ ${tr("catalog_test_connection_failed", lang)}: ${data.message}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("catalog_test_connection_failed")}: ${e.message}` }] };
        }
    });
    // ---- Test Embedding (NEW) ----
    server.tool("storefs_catalog_test_embedding", td("storefs_catalog_test_embedding"), {}, async () => {
        try {
            const data = await AdminClient.testCatalogEmbedding();
            const lang = LANG;
            if (data.success) {
                const lines = [
                    `✅ ${tr("catalog_test_embedding_success", lang)}`,
                    `  ${tr("catalog_connection_status", lang)}: ${data.status === "connected" ? tr("catalog_connected", lang) : data.status === "authentication_error" ? tr("catalog_authentication_error", lang) : tr("catalog_reachable", lang)}`,
                    `  ${tr("catalog_message", lang) || "Message"}: ${data.message}`,
                ];
                return { content: [{ type: "text", text: lines.join("\n") }] };
            }
            return { content: [{ type: "text", text: `❌ ${tr("catalog_test_embedding_failed", lang)}: ${data.message}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("catalog_test_embedding_failed")}: ${e.message}` }] };
        }
    });
}
