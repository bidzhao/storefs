import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { detectLang, LANG, tr, td } from "../i18n.js";
function formatSize(bytes, lang) {
    if (!bytes || bytes === 0)
        return "0 B";
    if (bytes >= 1e12)
        return (bytes / 1e12).toFixed(2) + " TB";
    if (bytes >= 1e9)
        return (bytes / 1e9).toFixed(2) + " GB";
    if (bytes >= 1e6)
        return (bytes / 1e6).toFixed(2) + " MB";
    if (bytes >= 1e3)
        return (bytes / 1e3).toFixed(2) + " KB";
    return bytes + " B";
}
function formatTime(ms) {
    if (!ms)
        return "-";
    // timestamp_ms 是毫秒 epoch；toISOString() 返回 UTC（去掉毫秒/时区后缀后为
    // "YYYY-MM-DD HH:MM:SS" UTC 字面值，与 DB/Admin API 的 UTC 时间基准一致）。
    const d = new Date(ms);
    return d.toISOString().replace("T", " ").substring(0, 19);
}
export function registerIcebergTools(server) {
    // ---- List Catalogs ----
    server.tool("storefs_iceberg_list_catalogs", td("storefs_iceberg_list_catalogs"), {}, async () => {
        const lang = LANG;
        try {
            const data = await AdminClient.listIcebergCatalogs();
            const cats = data.catalogs || [];
            if (cats.length === 0) {
                return { content: [{ type: "text", text: tr("iceberg_no_catalogs", lang) }] };
            }
            const lines = [
                `=== ${tr("iceberg_catalogs", lang)} ===`,
                "",
            ];
            for (const c of cats) {
                lines.push(`  ${c.name}  ->  ${c.warehouse}  (${tr("iceberg_catalog_status", lang)}: ${c.status ?? "ACTIVE"})`);
            }
            lines.push("", tr("iceberg_total", lang).replace("{n}", String(cats.length)));
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Get Catalog ----
    server.tool("storefs_iceberg_get_catalog", td("storefs_iceberg_get_catalog"), {
        name: z.string().describe(td("storefs_iceberg_get_catalog__name")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const res = await AdminClient.getIcebergCatalog(args.name);
            const c = res.catalog;
            const lines = [
                `=== ${tr("iceberg_catalog", lang)}: ${c.name} ===`,
                `  ${tr("iceberg_catalog_warehouse", lang)}: ${c.warehouse}`,
                `  ${tr("iceberg_catalog_owner", lang)}: ${c.owner_id ?? "-"}`,
                `  ${tr("iceberg_catalog_status", lang)}: ${c.status ?? "ACTIVE"}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Create Catalog ----
    server.tool("storefs_iceberg_create_catalog", td("storefs_iceberg_create_catalog"), {
        name: z.string().describe(td("storefs_iceberg_create_catalog__name")),
        warehouse: z.string().describe(td("storefs_iceberg_create_catalog__warehouse")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const res = await AdminClient.createIcebergCatalog({ name: args.name, warehouse: args.warehouse });
            const c = res.catalog;
            return { content: [{ type: "text", text: `${tr("iceberg_catalog_created", lang)}: ${c.name} -> ${c.warehouse}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Delete Catalog ----
    server.tool("storefs_iceberg_delete_catalog", td("storefs_iceberg_delete_catalog"), {
        name: z.string().describe(td("storefs_iceberg_delete_catalog__name")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            await AdminClient.deleteIcebergCatalog(args.name);
            return { content: [{ type: "text", text: `${tr("iceberg_catalog_deleted", lang)}: ${args.name}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- List Namespaces ----
    server.tool("storefs_iceberg_list_namespaces", td("storefs_iceberg_list_namespaces"), { catalog: z.string().optional().describe(td("storefs_iceberg_list_namespaces__catalog")) }, async (args) => {
        try {
            const data = await AdminClient.getIcebergNamespaces(args.catalog);
            const lang = LANG;
            const namespaces = data.namespaces || [];
            if (namespaces.length === 0) {
                return { content: [{ type: "text", text: tr("iceberg_no_namespaces", lang) }] };
            }
            const lines = [
                `=== ${tr("iceberg_namespaces", lang)} ===`,
                "",
            ];
            for (const ns of namespaces) {
                lines.push(`  ${ns.name}  (${tr("iceberg_tables", lang)}: ${ns.table_count ?? 0})`);
            }
            lines.push("", tr("iceberg_total", lang).replace("{n}", String(namespaces.length)));
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- List Tables ----
    server.tool("storefs_iceberg_list_tables", td("storefs_iceberg_list_tables"), {
        namespace: z.string().describe(td("storefs_iceberg_list_tables__namespace")),
        catalog: z.string().optional().describe(td("storefs_iceberg_list_tables__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const data = await AdminClient.getIcebergTables(args.namespace, args.catalog);
            const tables = data.tables || [];
            if (tables.length === 0) {
                return { content: [{ type: "text", text: tr("iceberg_no_tables", lang) }] };
            }
            const lines = [
                `=== ${args.namespace} — ${tr("iceberg_tables", lang)} ===`,
                "",
            ];
            for (const t of tables) {
                lines.push(`  ${t.name}  |  ${tr("iceberg_snapshots", lang)}: ${t.snapshot_count ?? 0}  |  ${tr("iceberg_size", lang)}: ${formatSize(t.size, lang)}`);
            }
            lines.push("", tr("iceberg_total", lang).replace("{n}", String(tables.length)));
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Get Table Schema ----
    server.tool("storefs_iceberg_get_schema", td("storefs_iceberg_get_schema"), {
        namespace: z.string().describe(td("storefs_iceberg_get_schema__namespace")),
        table: z.string().describe(td("storefs_iceberg_get_schema__table")),
        catalog: z.string().optional().describe(td("storefs_iceberg_get_schema__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const data = await AdminClient.getIcebergSchema(args.namespace, args.table, args.catalog);
            const schemas = data.schemas || [];
            const lines = [
                `=== ${args.namespace}.${args.table} — ${tr("iceberg_schema", lang)} ===`,
                "",
            ];
            // Find current schema
            const current = schemas.find((s) => s["schema-id"] === data.current_schema_id) || schemas[0];
            if (current && current.fields) {
                for (const f of current.fields) {
                    lines.push(`  ${f.id}: ${f.name}  ${f.type}  ${f.required ? "REQUIRED" : "OPTIONAL"}`);
                }
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- List Snapshots ----
    server.tool("storefs_iceberg_list_snapshots", td("storefs_iceberg_list_snapshots"), {
        namespace: z.string().describe(td("storefs_iceberg_list_snapshots__namespace")),
        table: z.string().describe(td("storefs_iceberg_list_snapshots__table")),
        catalog: z.string().optional().describe(td("storefs_iceberg_list_snapshots__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const data = await AdminClient.getIcebergSnapshots(args.namespace, args.table, args.catalog);
            const snapshots = data.snapshots || [];
            if (snapshots.length === 0) {
                return { content: [{ type: "text", text: tr("iceberg_no_snapshots", lang) }] };
            }
            const lines = [
                `=== ${args.namespace}.${args.table} — ${tr("iceberg_snapshots", lang)} ===`,
                "",
            ];
            for (const s of snapshots) {
                const op = (s.summary || {}).operation || "-";
                lines.push(`  #${s.snapshot_id}  seq=${s.sequence_number}  ${op}  ${formatTime(s.timestamp_ms)}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Storage Usage ----
    server.tool("storefs_iceberg_storage_usage", td("storefs_iceberg_storage_usage"), {
        namespace: z.string().optional().describe(td("storefs_iceberg_storage_usage__namespace")),
        catalog: z.string().optional().describe(td("storefs_iceberg_storage_usage__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const data = await AdminClient.getIcebergStorageUsage(args.namespace, args.catalog);
            const namespaces = data.namespaces || [];
            if (namespaces.length === 0) {
                return { content: [{ type: "text", text: tr("iceberg_no_data", lang) }] };
            }
            const lines = [
                `=== ${tr("iceberg_storage_usage", lang)} ===`,
                "",
            ];
            for (const ns of namespaces) {
                lines.push(`  ${ns.namespace}:  ${formatSize(ns.total_bytes, lang)}  (${ns.total_files ?? 0} ${tr("iceberg_files", lang).toLowerCase()})`);
                if (ns.approximate) {
                    lines.push(`    (${tr("iceberg_approximate", lang)})`);
                }
            }
            lines.push("", `  ${tr("iceberg_total", lang)}: ${formatSize(data.total_bytes, lang)}`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Get Config ----
    server.tool("storefs_iceberg_get_config", td("storefs_iceberg_get_config"), {}, async () => {
        const lang = LANG;
        try {
            const data = await AdminClient.getIcebergConfig();
            const lines = [
                `=== ${tr("iceberg_config", lang)} ===`,
                "",
                `  ${tr("iceberg_enabled", lang)}: ${data.enabled ? "true" : "false"}`,
                `  ${tr("iceberg_warehouse_bucket", lang)}: ${data.warehouse_bucket ?? "-"}`,
                `  ${tr("iceberg_default_namespace", lang)}: ${data.default_namespace ?? "-"}`,
                `  ${tr("iceberg_idempotency_retention_days", lang)}: ${data.idempotency_retention_days ?? "-"}`,
                `  ${tr("iceberg_orphan_grace_period_hours", lang)}: ${data.orphan_grace_period_hours ?? "-"}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Set Config ----
    server.tool("storefs_iceberg_set_config", td("storefs_iceberg_set_config"), {
        enabled: z.boolean().optional().describe(td("storefs_iceberg_set_config__enabled")),
        warehouse_bucket: z.string().optional().describe(td("storefs_iceberg_set_config__warehouse_bucket")),
        default_namespace: z.string().optional().describe(td("storefs_iceberg_set_config__default_namespace")),
        idempotency_retention_days: z.number().optional().describe(td("storefs_iceberg_set_config__idempotency_retention_days")),
        orphan_grace_period_hours: z.number().optional().describe(td("storefs_iceberg_set_config__orphan_grace_period_hours")),
    }, async (args) => {
        const lang = LANG;
        try {
            const clean = {};
            for (const [k, v] of Object.entries(args)) {
                if (v !== undefined && v !== null && v !== "")
                    clean[k] = v;
            }
            await AdminClient.putIcebergConfig(clean);
            return { content: [{ type: "text", text: tr("iceberg_config_saved", lang) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Get Feature Status ----
    server.tool("storefs_iceberg_get_status", td("storefs_iceberg_get_status"), {}, async () => {
        const lang = LANG;
        try {
            const data = await AdminClient.getIcebergStatus();
            const status = data.enabled ? tr("iceberg_enabled_status", lang) : tr("iceberg_disabled_status", lang);
            return { content: [{ type: "text", text: `${tr("iceberg_status", lang)}: ${status}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Enable ----
    server.tool("storefs_iceberg_enable", td("storefs_iceberg_enable"), {}, async () => {
        const lang = LANG;
        try {
            const res = await AdminClient.enableIceberg();
            return { content: [{ type: "text", text: res.message || tr("iceberg_config_saved", lang) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Disable ----
    server.tool("storefs_iceberg_disable", td("storefs_iceberg_disable"), {}, async () => {
        const lang = LANG;
        try {
            const res = await AdminClient.disableIceberg();
            return { content: [{ type: "text", text: res.message || tr("iceberg_config_saved", lang) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Get Table Detail ----
    server.tool("storefs_iceberg_get_table", td("storefs_iceberg_get_table"), {
        namespace: z.string().describe(td("storefs_iceberg_get_table__namespace")),
        table: z.string().describe(td("storefs_iceberg_get_table__table")),
        catalog: z.string().optional().describe(td("storefs_iceberg_get_table__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const t = await AdminClient.getIcebergTable(args.namespace, args.table, args.catalog);
            const lines = [
                `=== ${tr("iceberg_table_detail", lang)}: ${t.namespace}.${t.name} ===`,
                `  catalog: ${t.catalog ?? "-"}`,
                `  table_id: ${t.table_id ?? "-"}`,
                `  table_uuid: ${t.table_uuid ?? "-"}`,
                `  location: ${t.location ?? "-"}`,
                `  metadata_location: ${t.metadata_location ?? "-"}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- List Commits ----
    server.tool("storefs_iceberg_list_commits", td("storefs_iceberg_list_commits"), {
        namespace: z.string().describe(td("storefs_iceberg_list_commits__namespace")),
        table: z.string().describe(td("storefs_iceberg_list_commits__table")),
        catalog: z.string().optional().describe(td("storefs_iceberg_list_commits__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const data = await AdminClient.getIcebergCommits(args.namespace, args.table, args.catalog);
            const commits = data.commits || [];
            const lines = [
                `=== ${args.namespace}.${args.table} — ${tr("iceberg_commits", lang)} ===`,
                `  ${tr("iceberg_head_generation", lang)}: ${data.head_generation ?? 0}  |  ${tr("iceberg_commit_count", lang)}: ${data.commit_count ?? commits.length}`,
                "",
            ];
            if (commits.length === 0) {
                lines.push(tr("iceberg_no_data", lang));
            }
            for (const c of commits) {
                const id = c.commit_id ? c.commit_id.substring(0, 12) : "-";
                lines.push(`  ${c.created_at ?? "-"}  ${id}  gen=${c.head_generation ?? 0}->${c.base_head_generation ?? 0}  ${c.status ?? ""}  ${c.writer_id ?? ""}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Expire Snapshots (maintenance) ----
    server.tool("storefs_iceberg_expire_snapshots", td("storefs_iceberg_expire_snapshots"), {
        namespace: z.string().describe(td("storefs_iceberg_expire_snapshots__namespace")),
        table: z.string().describe(td("storefs_iceberg_expire_snapshots__table")),
        retain_last: z.number().optional().describe(td("storefs_iceberg_expire_snapshots__retain_last")),
        dry_run: z.boolean().optional().describe(td("storefs_iceberg_expire_snapshots__dry_run")),
        catalog: z.string().optional().describe(td("storefs_iceberg_expire_snapshots__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const res = await AdminClient.expireIcebergSnapshots(args.namespace, args.table, {
                retain_last: args.retain_last,
                dry_run: args.dry_run,
                catalog: args.catalog,
            });
            const lines = [
                `=== ${args.namespace}.${args.table} — ${tr("iceberg_expire_done", lang)} ===`,
                `  ${tr("iceberg_dry_run", lang)}: ${res.dry_run ? "true" : "false"}  |  ${tr("iceberg_candidates", lang)}: ${res.count ?? 0}`,
                "",
            ];
            const candidates = res.candidates || [];
            if (candidates.length === 0) {
                lines.push(tr("iceberg_no_candidates", lang));
            }
            for (const c of candidates) {
                lines.push(`  #${c.snapshot_id}  seq=${c.sequence_number ?? 0}  ${c.operation ?? "-"}  ${formatTime(c.timestamp_ms)}  ${c.manifest_list ?? ""}`);
            }
            if (res.deleted && res.deleted.length > 0) {
                lines.push("", `${tr("iceberg_deleted_count", lang)}: ${res.deleted.length}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Remove Orphan Files (maintenance) ----
    server.tool("storefs_iceberg_remove_orphan_files", td("storefs_iceberg_remove_orphan_files"), {
        namespace: z.string().describe(td("storefs_iceberg_remove_orphan_files__namespace")),
        table: z.string().describe(td("storefs_iceberg_remove_orphan_files__table")),
        dry_run: z.boolean().optional().describe(td("storefs_iceberg_remove_orphan_files__dry_run")),
        catalog: z.string().optional().describe(td("storefs_iceberg_remove_orphan_files__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const res = await AdminClient.removeIcebergOrphanFiles(args.namespace, args.table, {
                dry_run: args.dry_run,
                catalog: args.catalog,
            });
            const lines = [
                `=== ${args.namespace}.${args.table} — ${tr("iceberg_orphan_done", lang)} ===`,
                `  ${tr("iceberg_dry_run", lang)}: ${res.dry_run ? "true" : "false"}  |  ${tr("iceberg_candidates", lang)}: ${res.count ?? 0}  |  ${tr("iceberg_total_size", lang)}: ${formatSize(res.total_size, lang)}`,
                "",
            ];
            const candidates = res.candidates || [];
            if (candidates.length === 0) {
                lines.push(tr("iceberg_no_candidates", lang));
            }
            for (const c of candidates) {
                lines.push(`  ${c.key}  ${formatSize(c.size, lang)}  ${c.last_modified ? c.last_modified.substring(0, 19) : "-"}`);
            }
            if (res.deleted && res.deleted.length > 0) {
                lines.push("", `${tr("iceberg_deleted_count", lang)}: ${res.deleted.length}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Compact Metadata (maintenance) ----
    server.tool("storefs_iceberg_compact_metadata", td("storefs_iceberg_compact_metadata"), {
        namespace: z.string().describe(td("storefs_iceberg_compact_metadata__namespace")),
        table: z.string().describe(td("storefs_iceberg_compact_metadata__table")),
        dry_run: z.boolean().optional().describe(td("storefs_iceberg_compact_metadata__dry_run")),
        catalog: z.string().optional().describe(td("storefs_iceberg_compact_metadata__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const res = await AdminClient.compactIcebergMetadata(args.namespace, args.table, {
                dry_run: args.dry_run,
                catalog: args.catalog,
            });
            const lines = [
                `=== ${args.namespace}.${args.table} — ${tr("iceberg_compact_done", lang)} ===`,
                `  ${tr("iceberg_dry_run", lang)}: ${res.dry_run ? "true" : "false"}  |  ${tr("iceberg_chain_length", lang)}: ${res.chain?.chain_length ?? 0}`,
                `  compacted: ${res.compacted ? "true" : "false"}  |  deleted_old_metadata: ${res.deleted_old_metadata ?? 0}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Query ----
    server.tool("storefs_iceberg_query", td("storefs_iceberg_query"), {
        sql: z.string().describe(td("storefs_iceberg_query__sql")),
        namespace: z.string().describe(td("storefs_iceberg_query__namespace")),
        table: z.string().describe(td("storefs_iceberg_query__table")),
        limit: z.number().optional().describe(td("storefs_iceberg_query__limit")),
        catalog: z.string().optional().describe(td("storefs_iceberg_query__catalog")),
    }, async (args) => {
        detectLang({ ...args });
        const lang = LANG;
        try {
            const res = await AdminClient.queryIcebergTable(args.sql, args.namespace, args.table, {
                limit: args.limit,
                catalog: args.catalog,
            });
            const lines = [
                `=== ${tr("iceberg_query_result", lang)}: ${args.namespace}.${args.table} ===`,
                `  ${tr("iceberg_query_cols", lang)}: ${(res.columns || []).map((c) => `${c.name}:${c.type}`).join(", ")}`,
                `  ${tr("iceberg_total", lang).replace("{n}", String(res.row_count ?? 0))}`,
                "",
            ];
            const rows = res.rows || [];
            if (rows.length === 0) {
                lines.push(tr("iceberg_no_data", lang));
            }
            for (const row of rows) {
                const values = (res.columns || []).map((c) => {
                    const v = row[c.name];
                    return v === null || v === undefined ? "NULL" : String(v);
                });
                lines.push(`  ${values.join(" | ")}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("common_error", LANG)}: ${e.message}` }] };
        }
    });
}
