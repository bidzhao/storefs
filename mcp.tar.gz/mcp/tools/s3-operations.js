import { z } from "zod";
import * as S3Client from "../api/s3-client.js";
import * as AdminClient from "../api/admin-client.js";
import { getAuthHeader } from "../auth/admin-auth.js";
import { loadConfig } from "../config.js";
import { detectLang, LANG, tr, td, formatSize } from "../i18n.js";
import { readFile, writeFile, mkdir, access } from "node:fs/promises";
import * as path from "node:path";
import { execSync } from "node:child_process";
/** Detect binary Content-Types. */
function isBinaryContentType(ct) {
    const t = ct.toLowerCase().split(";")[0].trim();
    return (t.startsWith("image/") ||
        t.startsWith("audio/") ||
        t.startsWith("video/") ||
        t === "application/octet-stream" ||
        t === "application/zip" ||
        t === "application/gzip" ||
        t.includes("binary") ||
        t.startsWith("application/") && !t.endsWith("/json") && !t.endsWith("/xml") && !t.endsWith("+json") && !t.endsWith("+xml") && !t.includes("text"));
}
async function getS3Credentials() {
    const cfg = loadConfig();
    const res = await fetch(`${cfg.adminUrl.replace(/\/+$/, "")}/api/auth/user`, {
        headers: { Authorization: getAuthHeader() },
    });
    if (!res.ok)
        throw new Error(tr("need_login_s3"));
    const userData = (await res.json());
    const userId = userData.user?.id || userData.id;
    if (!userId)
        throw new Error(tr("need_login_s3"));
    const keys = await AdminClient.getAccessKeys(userId);
    if (keys.length === 0)
        throw new Error(tr("need_s3_keys"));
    return { accessKeyId: keys[0].accessKey, secretAccessKey: keys[0].secretKey };
}
export function registerS3Tools(server) {
    // ---- S3 List Buckets ----
    server.tool("storefs_s3_list_buckets", td("storefs_s3_list_buckets"), {}, async () => {
        try {
            const creds = await getS3Credentials();
            const buckets = await S3Client.listBuckets(creds);
            const lines = [`${tr("s3_bucket_list")} (${buckets.length}):`, ""];
            for (const b of buckets)
                lines.push(`  📦 ${b.name}  (${b.creationDate})`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- S3 Head Object ----
    server.tool("storefs_s3_head_object", td("storefs_s3_head_object"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        versionId: z.string().optional().describe(td("storefs__versionId")),
    }, async ({ bucketName, objectName, versionId }) => {
        try {
            const creds = await getS3Credentials();
            const headers = await S3Client.headObject(creds, bucketName, objectName, versionId);
            const cl = headers["content-length"] || "0";
            return { content: [{ type: "text", text: [
                            `${tr("object_metadata")} (${bucketName}/${objectName}):`,
                            `  Size: ${formatSize(parseInt(cl))}`,
                            `  ETag: ${headers["etag"] || "-"}`,
                            `  Content-Type: ${headers["content-type"] || "-"}`,
                            `  Last-Modified: ${headers["last-modified"] || "-"}`,
                            headers["x-amz-version-id"] ? `  Version: ${headers["x-amz-version-id"]}` : "",
                            headers["x-amz-delete-marker"] ? `  ⚠️ Delete marker` : "",
                        ].filter(Boolean).join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- S3 Get Object ----
    server.tool("storefs_s3_get_object", td("storefs_s3_get_object"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        versionId: z.string().optional().describe(td("storefs__versionId")),
        maxSize: z.number().optional().describe(td("storefs_s3_get_object__maxSize")),
    }, async ({ bucketName, objectName, versionId, maxSize }) => {
        try {
            const creds = await getS3Credentials();
            const result = await S3Client.getObject(creds, bucketName, objectName, versionId, maxSize);
            const limit = maxSize ?? 1_048_576;
            if (result.contentLength > limit) {
                return { content: [{ type: "text", text: [
                                `${tr("object_too_large")} (${formatSize(result.contentLength)})`,
                                `  Size: ${formatSize(result.contentLength)}`,
                                `  ETag: ${result.etag}`,
                                `  Content-Type: ${result.contentType}`,
                                `  提示: 可使用 storefs_s3_download_file 下载到本地`,
                            ].join("\n") }] };
            }
            let body = result.body;
            const truncated = body.length > 10000;
            if (truncated)
                body = body.slice(0, 10000) + `\n... ${tr("content_truncated")}, ~${formatSize(result.contentLength)}`;
            // 二进制内容提示保存文件
            if (isBinaryContentType(result.contentType)) {
                return { content: [{ type: "text", text: [
                                `${tr("object_content")} (${bucketName}/${objectName}):`,
                                `  Size: ${formatSize(result.contentLength)}`,
                                `  ETag: ${result.etag}`,
                                `  Content-Type: ${result.contentType}`,
                                `  ${tr("object_binary_save")}`,
                            ].join("\n") }] };
            }
            return { content: [{ type: "text", text: [
                            `${tr("object_content")} (${bucketName}/${objectName}):`,
                            `  Size: ${formatSize(result.contentLength)}`,
                            `  ETag: ${result.etag}`,
                            `  Content-Type: ${result.contentType}`,
                            "",
                            body,
                        ].join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- S3 Put Object ----
    server.tool("storefs_s3_put_object", td("storefs_s3_put_object"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        content: z.string().describe(td("storefs_s3_put_object__content")),
        contentType: z.string().optional().describe("Content-Type"),
        tags: z.string().optional().describe(td("storefs__tagging_header")),
    }, async ({ bucketName, objectName, content, contentType, tags }) => {
        detectLang({ content });
        const lang = LANG;
        try {
            const creds = await getS3Credentials();
            const result = await S3Client.putObject(creds, bucketName, objectName, content, contentType, tags);
            const lines = [`${tr("object_uploaded", lang)}: ${bucketName}/${objectName}`];
            lines.push(`  ETag: ${result.etag}`);
            if (result.versionId)
                lines.push(`  Version: ${result.versionId}`);
            if (tags)
                lines.push(`  Tags: ${tags}`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- S3 Delete Object ----
    server.tool("storefs_s3_delete_object", td("storefs_s3_delete_object"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        versionId: z.string().optional().describe(td("storefs__versionId")),
    }, async ({ bucketName, objectName, versionId }) => {
        try {
            const creds = await getS3Credentials();
            await S3Client.deleteObject(creds, bucketName, objectName, versionId);
            return { content: [{ type: "text", text: `${tr("object_s3_deleted")}: ${bucketName}/${objectName}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- S3 Copy Object ----
    server.tool("storefs_s3_copy_object", td("storefs_s3_copy_object"), {
        sourceBucket: z.string().describe(td("storefs__sourceBucket")),
        sourceObject: z.string().describe(td("storefs__sourceObject")),
        targetBucket: z.string().describe(td("storefs__targetBucket")),
        targetObject: z.string().describe(td("storefs__targetObject")),
        sourceVersionId: z.string().optional().describe(td("storefs__sourceVersionId")),
        taggingDirective: z.enum(["COPY", "REPLACE"]).optional().describe(td("storefs__tagging_directive")),
    }, async ({ sourceBucket, sourceObject, targetBucket, targetObject, sourceVersionId, taggingDirective }) => {
        try {
            const creds = await getS3Credentials();
            const headers = {};
            if (taggingDirective)
                headers["x-amz-tagging-directive"] = taggingDirective;
            const result = await S3Client.copyObject(creds, sourceBucket, sourceObject, targetBucket, targetObject, sourceVersionId, headers);
            return { content: [{ type: "text", text: [
                            `${tr("object_copied")}`,
                            `  From: ${sourceBucket}/${sourceObject}`,
                            `  To:   ${targetBucket}/${targetObject}`,
                            `  ETag: ${result.etag}`,
                        ].join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- S3 Upload File ----
    server.tool("storefs_s3_upload_file", td("storefs_s3_upload_file"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        filePath: z.string().describe(td("storefs_s3_upload_file__filePath")),
        contentType: z.string().optional().describe("Content-Type"),
        tags: z.string().optional().describe(td("storefs__tagging_header")),
    }, async ({ bucketName, objectName, filePath, contentType, tags }) => {
        try {
            await access(filePath);
            const content = await readFile(filePath);
            const creds = await getS3Credentials();
            const result = await S3Client.putObject(creds, bucketName, objectName, content, contentType, tags);
            const lines = [
                `${tr("file_uploaded_from")}: ${filePath}`,
                `  ${tr("object_from")}: ${bucketName}/${objectName}`,
                `  ETag: ${result.etag}`,
            ];
            if (result.versionId)
                lines.push(`  Version: ${result.versionId}`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            // Check if it's a file-not-found error
            if (e.code === "ENOENT") {
                return { content: [{ type: "text", text: `${tr("file_not_found")}: ${filePath}` }] };
            }
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- S3 Download File ----
    server.tool("storefs_s3_download_file", td("storefs_s3_download_file"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        filePath: z.string().describe(td("storefs_s3_download_file__filePath")),
        versionId: z.string().optional().describe(td("storefs__versionId")),
    }, async ({ bucketName, objectName, filePath, versionId }) => {
        try {
            const creds = await getS3Credentials();
            const result = await S3Client.getObjectAsBuffer(creds, bucketName, objectName, versionId);
            // Ensure parent directory exists
            const dir = path.dirname(filePath);
            await mkdir(dir, { recursive: true });
            // Write file
            await writeFile(filePath, Buffer.from(result.buffer));
            return { content: [{ type: "text", text: [
                            `${tr("file_saved")}: ${filePath}`,
                            `  ${tr("object_from")}: ${bucketName}/${objectName}`,
                            `  ${tr("size_label")}: ${formatSize(result.contentLength)}`,
                            `  ETag: ${result.etag}`,
                            `  Content-Type: ${result.contentType}`,
                        ].join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- S3 Get Object Tagging ----
    server.tool("storefs_s3_get_object_tagging", td("storefs_s3_get_object_tagging"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        versionId: z.string().optional().describe(td("storefs__versionId")),
    }, async (args) => {
        try {
            const creds = await getS3Credentials();
            const tags = await S3Client.getObjectTagging(creds, args.bucketName, args.objectName, args.versionId);
            if (tags.length === 0) {
                return { content: [{ type: "text", text: tr("tagging_no_tags") }] };
            }
            const lines = [tr("tagging_object_tags") + ":"];
            for (const t of tags)
                lines.push(`  ${t.key} = ${t.value}`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `\u274c ${e.message}` }] };
        }
    });
    // ---- S3 Put Object Tagging ----
    server.tool("storefs_s3_put_object_tagging", td("storefs_s3_put_object_tagging"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        tags: z.string().describe(td("storefs__tagging_tags")),
        versionId: z.string().optional().describe(td("storefs__versionId")),
    }, async (args) => {
        try {
            const tags = JSON.parse(args.tags);
            if (!Array.isArray(tags))
                throw new Error("tags must be a JSON array of {key, value}");
            for (const t of tags) {
                if (typeof t.key !== "string" || t.key.length < 1 || t.key.length > 128)
                    throw new Error("tag key must be 1-128 characters");
                if (typeof t.value !== "string" || t.value.length > 256)
                    throw new Error("tag value must be 0-256 characters");
            }
            const creds = await getS3Credentials();
            await S3Client.putObjectTagging(creds, args.bucketName, args.objectName, tags, args.versionId);
            return { content: [{ type: "text", text: `\u2705 ${tr("tagging_put_success")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `\u274c ${e.message}` }] };
        }
    });
    // ---- S3 Delete Object Tagging ----
    server.tool("storefs_s3_delete_object_tagging", td("storefs_s3_delete_object_tagging"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        versionId: z.string().optional().describe(td("storefs__versionId")),
    }, async (args) => {
        try {
            const creds = await getS3Credentials();
            await S3Client.deleteObjectTagging(creds, args.bucketName, args.objectName, args.versionId);
            return { content: [{ type: "text", text: `\u2705 ${tr("tagging_delete_success")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `\u274c ${e.message}` }] };
        }
    });
    // ---- S3 Get Bucket Tagging ----
    server.tool("storefs_s3_get_bucket_tagging", td("storefs_s3_get_bucket_tagging"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
    }, async (args) => {
        try {
            const creds = await getS3Credentials();
            const tags = await S3Client.getBucketTagging(creds, args.bucketName);
            if (tags.length === 0) {
                return { content: [{ type: "text", text: tr("tagging_no_tags") }] };
            }
            const lines = [tr("tagging_bucket_tags") + ":"];
            for (const t of tags)
                lines.push(`  ${t.key} = ${t.value}`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `\u274c ${e.message}` }] };
        }
    });
    // ---- S3 Put Bucket Tagging ----
    server.tool("storefs_s3_put_bucket_tagging", td("storefs_s3_put_bucket_tagging"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        tags: z.string().describe(td("storefs__tagging_tags")),
    }, async (args) => {
        try {
            const tags = JSON.parse(args.tags);
            if (!Array.isArray(tags))
                throw new Error("tags must be a JSON array of {key, value}");
            for (const t of tags) {
                if (typeof t.key !== "string" || t.key.length < 1 || t.key.length > 128)
                    throw new Error("tag key must be 1-128 characters");
                if (typeof t.value !== "string" || t.value.length > 256)
                    throw new Error("tag value must be 0-256 characters");
            }
            const creds = await getS3Credentials();
            await S3Client.putBucketTagging(creds, args.bucketName, tags);
            return { content: [{ type: "text", text: `\u2705 ${tr("tagging_put_success")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `\u274c ${e.message}` }] };
        }
    });
    // ---- S3 Delete Bucket Tagging ----
    server.tool("storefs_s3_delete_bucket_tagging", td("storefs_s3_delete_bucket_tagging"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
    }, async (args) => {
        try {
            const creds = await getS3Credentials();
            await S3Client.deleteBucketTagging(creds, args.bucketName);
            return { content: [{ type: "text", text: `\u2705 ${tr("tagging_delete_success")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `\u274c ${e.message}` }] };
        }
    });
    // ---- S3 Select Object ----
    server.tool("storefs_s3_select", td("storefs_s3_select"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        objectName: z.string().describe(td("storefs__objectName")),
        expression: z.string().default("SELECT * FROM S3Object").describe(td("storefs_s3_select__expression")),
        inputFormat: z.enum(["csv", "json"]).default("csv").describe(td("storefs_s3_select__inputFormat")),
        fileHeaderInfo: z.enum(["USE", "IGNORE", "NONE"]).default("USE").describe(td("storefs_s3_select__fileHeaderInfo")),
        jsonType: z.enum(["LINES", "DOCUMENT"]).default("LINES").describe(td("storefs_s3_select__jsonType")),
        outputFormat: z.enum(["csv", "json"]).default("csv").describe(td("storefs_s3_select__outputFormat")),
    }, async ({ bucketName, objectName, expression, inputFormat, fileHeaderInfo, jsonType, outputFormat }) => {
        try {
            const creds = await getS3Credentials();
            const s3selectPath = path.join(path.dirname(new URL(import.meta.url).pathname), "..", "..", "..", "s3client", "s3select");
            const args = [
                "-bucket", bucketName,
                "-object", objectName,
                "-expression", expression,
                "-input-format", inputFormat,
                "-output-format", outputFormat,
                "-endpoint", loadConfig().s3Url,
                "-ak", creds.accessKeyId,
                "-sk", creds.secretAccessKey,
            ];
            if (inputFormat === "csv") {
                args.push("-file-header-info", fileHeaderInfo);
            }
            if (inputFormat === "json") {
                args.push("-json-type", jsonType);
            }
            const stdout = execSync(`"${s3selectPath}" ${args.map(a => `"${a.replace(/"/g, '\\"')}"`).join(" ")}`, {
                timeout: 30000,
                encoding: "utf-8",
            });
            return { content: [{ type: "text", text: stdout }] };
        }
        catch (e) {
            const msg = e.stderr ? e.stderr.toString() : e.message;
            return { content: [{ type: "text", text: `\u274c ${msg}` }] };
        }
    });
}
