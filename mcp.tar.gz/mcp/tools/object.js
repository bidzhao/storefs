import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { tr, td, formatSize } from "../i18n.js";
import { bucketNameParam, bucketRef } from "../utils/bucket-ref.js";
export function registerObjectTools(server) {
    // ---- List Objects ----
    server.tool("storefs_list_objects", td("storefs_list_objects"), {
        bucketId: z.string().optional().describe(td("storefs__bucketId")),
        ...bucketNameParam(),
        page: z.number().optional(),
        pageSize: z.number().optional(),
        showDelete: z.boolean().optional().describe(td("storefs_list_objects__showDelete")),
    }, async ({ bucketId, bucketName, page, pageSize, showDelete }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const data = await AdminClient.listObjects(ref, { page, pageSize, showDelete });
            const objects = data.objects || [];
            const lines = [`${tr("object_list_title")} (${tr("total_objects").replace("{n}", String(objects.length))}):`, ""];
            for (const o of objects) {
                const sizeStr = formatSize(parseInt(o.size));
                const flags = [];
                if (o.isDeleted)
                    flags.push("🗑");
                if (o.hasVersion)
                    flags.push("v");
                if (o.isEncrypted)
                    flags.push("🔒");
                lines.push(`  📄 ${o.objectName}  ${flags.join(" ")}`);
                lines.push(`    ${sizeStr}  |  CRC: ${o.crc}`);
                lines.push(`    ${tr("status_label")}: ${o.status}`);
                lines.push(`    ${tr("write_time")}: ${o.writeTime}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Object Info ----
    server.tool("storefs_get_object_info", td("storefs_get_object_info"), {
        bucketName: z.string().describe(td("storefs_get_object_info__bucketName")),
        objectName: z.string().describe(td("storefs_get_object_info__objectName")),
    }, async ({ bucketName, objectName }) => {
        try {
            const info = await AdminClient.getObjectInfo(bucketName, objectName);
            return { content: [{ type: "text", text: JSON.stringify(info, null, 2) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Object Versions ----
    server.tool("storefs_get_object_versions", td("storefs_get_object_versions"), {
        bucketId: z.string().optional().describe(td("storefs__bucketId")),
        ...bucketNameParam(),
        objectName: z.string().describe(td("storefs__objectName")),
        page: z.number().optional(),
        pageSize: z.number().optional(),
    }, async ({ bucketId, bucketName, objectName, page, pageSize }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const data = await AdminClient.getObjectVersions(ref, objectName, { page, pageSize });
            const versions = data.versions || [];
            const lines = [`${tr("object_versions_title")} (${tr("total_objects").replace("{n}", String(versions.length))}):`, ""];
            for (const v of versions) {
                const sizeStr = formatSize(parseInt(v.size));
                const flags = [v.isLatest ? "★" : "", v.isDeleted ? "🗑" : "", v.isEncrypted ? "🔒" : ""].filter(Boolean);
                lines.push(`  [${v.version}] ${v.objectName}  ${flags.join(" ")}`);
                lines.push(`    ${sizeStr}  |  CRC: ${v.crc}`);
                lines.push(`    ${tr("status_label")}: ${v.status}`);
                lines.push(`    ${tr("write_time")}: ${v.writeTime}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete Object ----
    server.tool("storefs_delete_object", td("storefs_delete_object"), {
        bucketId: z.string().optional().describe(td("storefs__bucketId")),
        ...bucketNameParam(),
        objectName: z.string().describe(td("storefs__objectName")),
        version: z.string().optional().describe(td("storefs_delete_object__version")),
    }, async ({ bucketId, bucketName, objectName, version }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            await AdminClient.deleteObject(ref, objectName, version);
            return { content: [{ type: "text", text: `${tr("object_deleted")}: ${objectName}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List Multipart Uploads ----
    server.tool("storefs_list_multipart_uploads", td("storefs_list_multipart_uploads"), {
        bucketId: z.string().optional().describe(td("storefs__bucketId")),
        ...bucketNameParam(),
        page: z.number().optional(),
        pageSize: z.number().optional(),
    }, async ({ bucketId, bucketName, page, pageSize }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const data = await AdminClient.listMultipartUploads(ref, { page, pageSize });
            const lines = [`${tr("multipart_list_title")} (${tr("total_uploads").replace("{n}", String(data.total))}):`, ""];
            for (const u of data.uploads) {
                lines.push(`  📤 ${u.objectName}`);
                lines.push(`    UploadID: ${u.uploadId}`);
                lines.push(`    ${tr("status_label")}: ${u.status}  |  🔒 ${u.isEncrypted ? tr("yes") : tr("no")}`);
                lines.push(`    ${tr("created_at_label")}: ${u.initiatedTime}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Multipart Upload ----
    server.tool("storefs_get_multipart_upload", td("storefs_get_multipart_upload"), {
        uploadId: z.string().describe(td("storefs__uploadId")),
        bucketId: z.string().optional().describe(td("storefs__bucketId")),
        ...bucketNameParam(),
        objectName: z.string().describe(td("storefs__objectName")),
    }, async ({ uploadId, bucketId, bucketName, objectName }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const data = await AdminClient.getMultipartUpload(uploadId, ref, objectName);
            const lines = [
                `${tr("multipart_upload_detail")}:`,
                `  Object: ${data.objectName}`,
                `  UploadID: ${data.uploadId}`,
                `  ${tr("status_label")}: ${data.status}`,
                `  🔒 ${data.isEncrypted ? tr("bucket_enabled") : tr("no")}`,
                `  SSE-C: ${data.isSSEC ? "yes" : "no"}`,
                `  ${tr("created_at_label")}: ${data.initiatedTime}`,
                data.expirationTime ? `  Expiration: ${data.expirationTime}` : "",
                "",
            ];
            if (data.tags && data.tags.length > 0) {
                lines.push(`Tags:`);
                for (const t of data.tags) {
                    lines.push(`  ${t.key} = ${t.value}`);
                }
                lines.push("");
            }
            lines.push(`Parts (${data.parts?.length || 0}):`);
            lines.push("");
            for (const p of data.parts || []) {
                lines.push(`  Part ${p.partNumber}: ${formatSize(parseInt(p.size))}  |  CRC: ${p.crc}  |  ${p.uploadTime}`);
            }
            return { content: [{ type: "text", text: lines.filter(Boolean).join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Complete Multipart Upload ----
    server.tool("storefs_complete_multipart_upload", td("storefs_complete_multipart_upload"), {
        uploadId: z.string().describe(td("storefs__uploadId")),
        bucketId: z.string().optional().describe(td("storefs__bucketId")),
        ...bucketNameParam(),
        objectName: z.string().describe(td("storefs__objectName")),
        partNumbers: z.array(z.number()).optional().describe(td("storefs_complete_multipart_upload__partNumbers")),
    }, async ({ uploadId, bucketId, bucketName, objectName, partNumbers }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            await AdminClient.completeMultipartUpload(uploadId, ref, objectName, partNumbers);
            return { content: [{ type: "text", text: tr("multipart_completed") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Abort Multipart Upload ----
    server.tool("storefs_abort_multipart_upload", td("storefs_abort_multipart_upload"), {
        uploadId: z.string().describe(td("storefs__uploadId")),
        bucketId: z.string().optional().describe(td("storefs__bucketId")),
        ...bucketNameParam(),
        objectName: z.string().describe(td("storefs__objectName")),
    }, async ({ uploadId, bucketId, bucketName, objectName }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            await AdminClient.abortMultipartUpload(uploadId, ref, objectName);
            return { content: [{ type: "text", text: tr("multipart_aborted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Part Fragment Info ----
    server.tool("storefs_get_part_fragment_info", td("storefs_get_part_fragment_info"), {
        uploadId: z.string().describe(td("storefs__uploadId")),
        partNumber: z.number().describe(td("storefs__partNumber")),
        bucketId: z.string().optional().describe(td("storefs__bucketId")),
        ...bucketNameParam(),
        objectName: z.string().describe(td("storefs__objectName")),
    }, async ({ uploadId, partNumber, bucketId, bucketName, objectName }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const fragments = await AdminClient.getPartFragmentInfo(uploadId, partNumber, ref, objectName);
            const lines = [`Part ${partNumber} ${tr("fragment_distribution")} (${fragments.length}):`, ""];
            for (const f of fragments) {
                const icon = f.status === "normal" ? "✅" : f.status === "offline" ? "⚫" : "❌";
                lines.push(`  ${icon} ${f.nodeName} (${f.nodeIP})`);
                lines.push(`    ${f.diskDir}  ${f.path}`);
                lines.push(`    ${formatSize(parseInt(f.fragmentSize))}  |  CRC: ${f.crc}  |  ${f.status}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
}
