import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { tr, LANG, detectLang, td } from "../i18n.js";
// IAM (Identity & Access) management tools — Web Console /api/iam/* endpoints.
// Requires a legacy super_admin or an IAM user with StoreFSConsoleAdmin.
export function registerIamTools(server) {
    // ---- Account Summary ----
    server.tool("storefs_iam_account_summary", td("storefs_iam_account_summary"), { account: z.string().optional().describe(td("storefs_iam_account_summary__account")) }, async ({ account }) => {
        try {
            const s = await AdminClient.getIAMAccountSummary(account);
            return {
                content: [{
                        type: "text",
                        text: [
                            `${tr("iam_account_summary_title")}:`,
                            `  ${tr("iam_users")}: ${s.users}`,
                            `  ${tr("iam_groups")}: ${s.groups}`,
                            `  ${tr("iam_roles")}: ${s.roles}`,
                            `  ${tr("iam_policies")}: ${s.policies}`,
                            `  ${tr("iam_access_keys")}: ${s.accessKeys}`,
                            `  ${tr("iam_oidc_providers")}: ${s.oidcProviders}`,
                        ].join("\n"),
                    }],
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List IAM Users ----
    server.tool("storefs_iam_list_users", td("storefs_iam_list_users"), {
        page: z.number().optional().describe(td("storefs_iam_list_users__page")),
        pageSize: z.number().optional().describe(td("storefs_iam_list_users__pageSize")),
        account: z.string().optional().describe(td("storefs_iam_list_users__account")),
    }, async ({ page, pageSize, account }) => {
        try {
            const data = await AdminClient.listIAMUsers({ page, pageSize, account });
            const lines = [`${tr("iam_users_title")} (${tr("total").replace("{n}", String(data.total))}):`, ""];
            for (const u of data.items) {
                lines.push(`  [${u.id}] ${u.userName}`);
                if (u.path && u.path !== "/")
                    lines.push(`     ${tr("iam_path")}: ${u.path}`);
                if (u.groups && u.groups.length)
                    lines.push(`     ${tr("iam_groups")}: ${u.groups.join(", ")}`);
                lines.push(`     ${tr("iam_access_keys")}: ${u.accessKeyCount}`);
                lines.push(`     ${tr("created_at_label")}: ${u.createdAt}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get IAM User ----
    server.tool("storefs_iam_get_user", td("storefs_iam_get_user"), { userId: z.string().describe(td("storefs_iam_get_user__userId")) }, async ({ userId }) => {
        try {
            const u = await AdminClient.getIAMUser(userId);
            const lines = [
                `${tr("iam_user_detail_title")}:`,
                `  ${tr("iam_user_name")}: ${u.userName}`,
                `  ID: ${u.id}`,
                `  ARN: ${u.arn}`,
                `  ${tr("iam_path")}: ${u.path || "/"}`,
                u.email ? `  ${tr("email_label")}: ${u.email}` : "",
                u.groups && u.groups.length ? `  ${tr("iam_groups")}: ${u.groups.join(", ")}` : "",
                `  ${tr("iam_access_keys")}: ${u.accessKeyCount}`,
                `  ${tr("created_at_label")}: ${u.createdAt}`,
            ].filter(Boolean).join("\n");
            return { content: [{ type: "text", text: lines }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create IAM User ----
    server.tool("storefs_iam_create_user", td("storefs_iam_create_user"), {
        name: z.string().describe(td("storefs_iam_create_user__name")),
        path: z.string().optional().describe(td("storefs_iam_create_user__path")),
        email: z.string().optional().describe(td("storefs_iam_create_user__email")),
    }, async ({ name, path, email }) => {
        detectLang({ name });
        const lang = LANG;
        try {
            const u = await AdminClient.createIAMUser({ name, path, email });
            return { content: [{ type: "text", text: `${tr("iam_user_created", lang)}: [${u.id}] ${u.userName}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update IAM User ----
    server.tool("storefs_iam_update_user", td("storefs_iam_update_user"), {
        userId: z.string().describe(td("storefs_iam_update_user__userId")),
        path: z.string().optional().describe(td("storefs_iam_update_user__path")),
        email: z.string().optional().describe(td("storefs_iam_update_user__email")),
    }, async ({ userId, path, email }) => {
        try {
            const u = await AdminClient.updateIAMUser(userId, { path, email });
            return { content: [{ type: "text", text: `${tr("iam_user_updated")}: ${u.userName}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete IAM User ----
    server.tool("storefs_iam_delete_user", td("storefs_iam_delete_user"), { userId: z.string().describe(td("storefs_iam_delete_user__userId")) }, async ({ userId }) => {
        try {
            await AdminClient.deleteIAMUser(userId);
            return { content: [{ type: "text", text: tr("iam_user_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List IAM Access Keys ----
    server.tool("storefs_iam_list_access_keys", td("storefs_iam_list_access_keys"), { userId: z.string().describe(td("storefs_iam_list_access_keys__userId")) }, async ({ userId }) => {
        try {
            const data = await AdminClient.listIAMAccessKeys(userId);
            if (data.items.length === 0) {
                return { content: [{ type: "text", text: tr("iam_no_access_keys") }] };
            }
            const lines = data.items.map((k) => `  ${tr("iam_access_key")}: ${k.accessKey}\n  ${tr("iam_status")}: ${k.status}\n  ${tr("created_at_label")}: ${k.createdAt || ""}`);
            return { content: [{ type: "text", text: `${tr("iam_access_keys_title")}:\n\n${lines.join("\n\n")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create IAM Access Key ----
    server.tool("storefs_iam_create_access_key", td("storefs_iam_create_access_key"), { userId: z.string().describe(td("storefs_iam_create_access_key__userId")) }, async ({ userId }) => {
        detectLang({ userId });
        const lang = LANG;
        try {
            const k = await AdminClient.createIAMAccessKey(userId);
            return {
                content: [{
                        type: "text",
                        text: [
                            tr("iam_access_key_created", lang),
                            `  ${tr("iam_access_key")}: ${k.accessKey}`,
                            `  ${tr("iam_secret_key")}: ${k.secretAccessKey}`,
                            `  ${tr("iam_status")}: ${k.status}`,
                            `  ${tr("iam_secret_once_hint")}`,
                        ].join("\n"),
                    }],
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update IAM Access Key Status ----
    server.tool("storefs_iam_update_access_key_status", td("storefs_iam_update_access_key_status"), {
        userId: z.string().describe(td("storefs_iam_update_access_key_status__userId")),
        keyId: z.string().describe(td("storefs_iam_update_access_key_status__keyId")),
        status: z.enum(["Active", "Inactive"]).describe(td("storefs_iam_update_access_key_status__status")),
    }, async ({ userId, keyId, status }) => {
        try {
            await AdminClient.updateIAMAccessKeyStatus(userId, keyId, status);
            return { content: [{ type: "text", text: `${tr("iam_access_key_status_updated")}: ${keyId} → ${status}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete IAM Access Key ----
    server.tool("storefs_iam_delete_access_key", td("storefs_iam_delete_access_key"), {
        userId: z.string().describe(td("storefs_iam_delete_access_key__userId")),
        keyId: z.string().describe(td("storefs_iam_delete_access_key__keyId")),
    }, async ({ userId, keyId }) => {
        try {
            await AdminClient.deleteIAMAccessKey(userId, keyId);
            return { content: [{ type: "text", text: tr("iam_access_key_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List IAM Groups ----
    server.tool("storefs_iam_list_groups", td("storefs_iam_list_groups"), {
        page: z.number().optional().describe(td("storefs_iam_list_groups__page")),
        pageSize: z.number().optional().describe(td("storefs_iam_list_groups__pageSize")),
    }, async ({ page, pageSize }) => {
        try {
            const data = await AdminClient.listIAMGroups({ page, pageSize });
            const lines = [`${tr("iam_groups_title")} (${tr("total").replace("{n}", String(data.total))}):`, ""];
            for (const g of data.items) {
                lines.push(`  [${g.id}] ${g.groupName}`);
                lines.push(`     ${tr("iam_path")}: ${g.path || "/"}`);
                if (g.userCount !== undefined)
                    lines.push(`     ${tr("iam_members")}: ${g.userCount}`);
                if (g.policyCount !== undefined)
                    lines.push(`     ${tr("iam_inline_policy_count")}: ${g.policyCount}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get IAM Group ----
    server.tool("storefs_iam_get_group", td("storefs_iam_get_group"), { groupId: z.string().describe(td("storefs_iam_get_group__groupId")) }, async ({ groupId }) => {
        try {
            const g = await AdminClient.getIAMGroup(groupId);
            const lines = [
                `${tr("iam_group_detail_title")}:`,
                `  ${tr("iam_group_name")}: ${g.groupName}`,
                `  ID: ${g.id}`,
                `  ARN: ${g.arn}`,
                `  ${tr("iam_path")}: ${g.path || "/"}`,
                `  ${tr("iam_members")}: ${g.userCount ?? 0}`,
                `  ${tr("iam_inline_policy_count")}: ${g.policyCount ?? 0}`,
            ].join("\n");
            return { content: [{ type: "text", text: lines }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create IAM Group ----
    server.tool("storefs_iam_create_group", td("storefs_iam_create_group"), {
        name: z.string().describe(td("storefs_iam_create_group__name")),
        path: z.string().optional().describe(td("storefs_iam_create_group__path")),
    }, async ({ name, path }) => {
        detectLang({ name });
        const lang = LANG;
        try {
            const g = await AdminClient.createIAMGroup({ name, path });
            return { content: [{ type: "text", text: `${tr("iam_group_created", lang)}: [${g.id}] ${g.groupName}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete IAM Group ----
    server.tool("storefs_iam_delete_group", td("storefs_iam_delete_group"), { groupId: z.string().describe(td("storefs_iam_delete_group__groupId")) }, async ({ groupId }) => {
        try {
            await AdminClient.deleteIAMGroup(groupId);
            return { content: [{ type: "text", text: tr("iam_group_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List IAM Group Members ----
    server.tool("storefs_iam_list_group_members", td("storefs_iam_list_group_members"), { groupId: z.string().describe(td("storefs_iam_list_group_members__groupId")) }, async ({ groupId }) => {
        try {
            const data = await AdminClient.listIAMGroupMembers(groupId);
            if (data.items.length === 0) {
                return { content: [{ type: "text", text: tr("iam_no_members") }] };
            }
            const lines = data.items.map((u) => `  [${u.id}] ${u.userName}`);
            return { content: [{ type: "text", text: `${tr("iam_members_title")} (${tr("total").replace("{n}", String(data.total))}):\n${lines.join("\n")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Add IAM Group Member ----
    server.tool("storefs_iam_add_group_member", td("storefs_iam_add_group_member"), {
        groupId: z.string().describe(td("storefs_iam_add_group_member__groupId")),
        userId: z.string().describe(td("storefs_iam_add_group_member__userId")),
    }, async ({ groupId, userId }) => {
        try {
            await AdminClient.addIAMGroupMember(groupId, userId);
            return { content: [{ type: "text", text: tr("iam_member_added") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Remove IAM Group Member ----
    server.tool("storefs_iam_remove_group_member", td("storefs_iam_remove_group_member"), {
        groupId: z.string().describe(td("storefs_iam_remove_group_member__groupId")),
        userId: z.string().describe(td("storefs_iam_remove_group_member__userId")),
    }, async ({ groupId, userId }) => {
        try {
            await AdminClient.removeIAMGroupMember(groupId, userId);
            return { content: [{ type: "text", text: tr("iam_member_removed") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List Managed Policies ----
    server.tool("storefs_iam_list_policies", td("storefs_iam_list_policies"), {
        page: z.number().optional().describe(td("storefs_iam_list_policies__page")),
        pageSize: z.number().optional().describe(td("storefs_iam_list_policies__pageSize")),
        filter: z.enum(["all", "aws", "customer"]).optional().describe(td("storefs_iam_list_policies__filter")),
    }, async ({ page, pageSize, filter }) => {
        try {
            const data = await AdminClient.listIAMManagedPolicies({ page, pageSize, filter });
            const lines = [`${tr("iam_policies_title")} (${tr("total").replace("{n}", String(data.total))}):`, ""];
            for (const p of data.items) {
                lines.push(`  ${p.policyName}`);
                lines.push(`     ARN: ${p.arn}`);
                lines.push(`     ${tr("iam_policy_type")}: ${p.isAWSCustomer ? tr("iam_customer_managed") : tr("iam_aws_managed")}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Managed Policy ----
    server.tool("storefs_iam_get_policy", td("storefs_iam_get_policy"), { policyId: z.string().describe(td("storefs_iam_get_policy__policyId")) }, async ({ policyId }) => {
        try {
            const p = await AdminClient.getIAMManagedPolicy(policyId);
            const lines = [
                `${tr("iam_policy_detail_title")}:`,
                `  ${tr("iam_policy_name")}: ${p.policyName}`,
                `  ARN: ${p.arn}`,
                `  ${tr("iam_policy_type")}: ${p.isAWSCustomer ? tr("iam_customer_managed") : tr("iam_aws_managed")}`,
                p.document ? `\n${tr("iam_policy_document")}:\n${p.document}` : "",
            ].filter(Boolean).join("\n");
            return { content: [{ type: "text", text: lines }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List IAM Roles ----
    server.tool("storefs_iam_list_roles", td("storefs_iam_list_roles"), {
        page: z.number().optional().describe(td("storefs_iam_list_roles__page")),
        pageSize: z.number().optional().describe(td("storefs_iam_list_roles__pageSize")),
    }, async ({ page, pageSize }) => {
        try {
            const data = await AdminClient.listIAMRoles({ page, pageSize });
            const lines = [`${tr("iam_roles_title")} (${tr("total").replace("{n}", String(data.total))}):`, ""];
            for (const r of data.items) {
                lines.push(`  [${r.id}] ${r.roleName}`);
                lines.push(`     ARN: ${r.arn}`);
                if (r.description)
                    lines.push(`     ${tr("iam_description")}: ${r.description}`);
                if (r.inlinePolicyCount !== undefined)
                    lines.push(`     ${tr("iam_inline_policy_count")}: ${r.inlinePolicyCount}`);
                if (r.attachedPolicyCount !== undefined)
                    lines.push(`     ${tr("iam_attached_policy_count")}: ${r.attachedPolicyCount}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get IAM Role ----
    server.tool("storefs_iam_get_role", td("storefs_iam_get_role"), { roleId: z.string().describe(td("storefs_iam_get_role__roleId")) }, async ({ roleId }) => {
        try {
            const r = await AdminClient.getIAMRole(roleId);
            const lines = [
                `${tr("iam_role_detail_title")}:`,
                `  ${tr("iam_role_name")}: ${r.roleName}`,
                `  ID: ${r.id}`,
                `  ARN: ${r.arn}`,
                `  ${tr("iam_path")}: ${r.path || "/"}`,
                r.description ? `  ${tr("iam_description")}: ${r.description}` : "",
                r.maxSessionDuration ? `  ${tr("iam_max_session_duration")}: ${r.maxSessionDuration}` : "",
                `  ${tr("iam_inline_policy_count")}: ${r.inlinePolicyCount ?? 0}`,
                `  ${tr("iam_attached_policy_count")}: ${r.attachedPolicyCount ?? 0}`,
            ].filter(Boolean).join("\n");
            return { content: [{ type: "text", text: lines }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create IAM Role ----
    server.tool("storefs_iam_create_role", td("storefs_iam_create_role"), {
        roleName: z.string().describe(td("storefs_iam_create_role__roleName")),
        trustPolicy: z.string().describe(td("storefs_iam_create_role__trustPolicy")),
        path: z.string().optional().describe(td("storefs_iam_create_role__path")),
        description: z.string().optional().describe(td("storefs_iam_create_role__description")),
        maxSessionDuration: z.number().optional().describe(td("storefs_iam_create_role__maxSessionDuration")),
    }, async ({ roleName, trustPolicy, path, description, maxSessionDuration }) => {
        detectLang({ roleName });
        const lang = LANG;
        try {
            const r = await AdminClient.createIAMRole({ roleName, trustPolicy, path, description, maxSessionDuration });
            return { content: [{ type: "text", text: `${tr("iam_role_created", lang)}: [${r.id}] ${r.roleName}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete IAM Role ----
    server.tool("storefs_iam_delete_role", td("storefs_iam_delete_role"), { roleId: z.string().describe(td("storefs_iam_delete_role__roleId")) }, async ({ roleId }) => {
        try {
            await AdminClient.deleteIAMRole(roleId);
            return { content: [{ type: "text", text: tr("iam_role_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get IAM Role Trust Policy ----
    server.tool("storefs_iam_get_role_trust_policy", td("storefs_iam_get_role_trust_policy"), { roleId: z.string().describe(td("storefs_iam_get_role_trust_policy__roleId")) }, async ({ roleId }) => {
        try {
            const t = await AdminClient.getIAMRoleTrustPolicy(roleId);
            return { content: [{ type: "text", text: `${tr("iam_trust_policy_title")}:\n${t.assumeRolePolicyDocument}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update IAM Role Trust Policy ----
    server.tool("storefs_iam_update_role_trust_policy", td("storefs_iam_update_role_trust_policy"), {
        roleId: z.string().describe(td("storefs_iam_update_role_trust_policy__roleId")),
        document: z.string().describe(td("storefs_iam_update_role_trust_policy__document")),
    }, async ({ roleId, document }) => {
        try {
            await AdminClient.updateIAMRoleTrustPolicy(roleId, document);
            return { content: [{ type: "text", text: tr("iam_trust_policy_updated") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List OIDC Providers ----
    server.tool("storefs_iam_list_oidc_providers", td("storefs_iam_list_oidc_providers"), {}, async () => {
        try {
            const data = await AdminClient.listIAMOIDCProviders();
            if (data.items.length === 0) {
                return { content: [{ type: "text", text: tr("iam_no_oidc_providers") }] };
            }
            const lines = data.items.map((p) => {
                const cids = p.clientIds && p.clientIds.length ? p.clientIds.join(", ") : tr("iam_none");
                return `  [${p.id}] ${p.url}\n     ARN: ${p.arn}\n     ${tr("iam_client_ids")}: ${cids}`;
            });
            return { content: [{ type: "text", text: `${tr("iam_oidc_providers_title")}:\n\n${lines.join("\n\n")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create OIDC Provider ----
    server.tool("storefs_iam_create_oidc_provider", td("storefs_iam_create_oidc_provider"), {
        url: z.string().describe(td("storefs_iam_create_oidc_provider__url")),
        clientIds: z.array(z.string()).optional().describe(td("storefs_iam_create_oidc_provider__clientIds")),
    }, async ({ url, clientIds }) => {
        detectLang({ url });
        const lang = LANG;
        try {
            const p = await AdminClient.createIAMOIDCProvider({ url, clientIds: clientIds ?? [] });
            return { content: [{ type: "text", text: `${tr("iam_oidc_created", lang)}: [${p.id}] ${p.url}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete OIDC Provider ----
    server.tool("storefs_iam_delete_oidc_provider", td("storefs_iam_delete_oidc_provider"), { providerId: z.string().describe(td("storefs_iam_delete_oidc_provider__providerId")) }, async ({ providerId }) => {
        try {
            await AdminClient.deleteIAMOIDCProvider(providerId);
            return { content: [{ type: "text", text: tr("iam_oidc_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
}
