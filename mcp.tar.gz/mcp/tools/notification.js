import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { detectLang, LANG, tr, td } from "../i18n.js";
import { bucketNameParam, bucketRef } from "../utils/bucket-ref.js";
export function registerNotificationTools(server) {
    // ---- List Bucket Notifications ----
    server.tool("storefs_list_bucket_notifications", td("storefs_list_bucket_notifications"), {
        bucketId: z.string().optional().describe(td("storefs_notification__bucketId")),
        ...bucketNameParam(),
    }, async ({ bucketId, bucketName }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const data = await AdminClient.listBucketNotifications(ref);
            const lines = [
                `${tr("notification_list_title")} (${tr("total_notifications").replace("{n}", String(data.total))}):`,
                "",
            ];
            for (const n of data.notifications) {
                const status = n.enabled ? tr("enabled") : tr("disabled");
                lines.push(`  [${n.id}] ${n.url}`);
                lines.push(`    ${tr("notification_events_label")}: ${n.events}`);
                lines.push(`    ${tr("notification_format_label")}: ${n.format}  |  ${tr("status_label")}: ${status}`);
                if (n.filterPrefix)
                    lines.push(`    ${tr("notification_prefix_label")}: ${n.filterPrefix}`);
                if (n.filterSuffix)
                    lines.push(`    ${tr("notification_suffix_label")}: ${n.filterSuffix}`);
                lines.push(`    ${tr("created_at_label")}: ${n.createdAt}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Notification ----
    server.tool("storefs_get_notification", td("storefs_get_notification"), {
        notificationId: z.string().describe(td("storefs_notification__id")),
    }, async ({ notificationId }) => {
        try {
            const n = await AdminClient.getNotification(notificationId);
            const lines = [
                `${tr("notification_detail_title")}:`,
                `  ID: ${n.id}`,
                `  ${tr("bucket_id_label")}: ${n.bucketId}`,
                `  URL: ${n.url}`,
                `  ${tr("notification_events_label")}: ${n.events}`,
                `  ${tr("notification_format_label")}: ${n.format}`,
                `  ${tr("status_label")}: ${n.enabled ? tr("enabled") : tr("disabled")}`,
                `  ${tr("retry_count_label")}: ${n.retryCount}`,
                `  ${tr("retry_interval_label")}: ${n.retryInterval}s`,
            ];
            if (n.filterPrefix) {
                lines.push(`  ${tr("notification_prefix_label")}: ${n.filterPrefix}`);
            }
            if (n.filterSuffix) {
                lines.push(`  ${tr("notification_suffix_label")}: ${n.filterSuffix}`);
            }
            lines.push(`  ${tr("created_at_label")}: ${n.createdAt}`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create Notification ----
    server.tool("storefs_create_notification", td("storefs_create_notification"), {
        bucketId: z.string().optional().describe(td("storefs_notification__bucketId")),
        ...bucketNameParam(),
        url: z.string().url().describe(td("storefs_notification__url")),
        secret: z.string().optional().describe(td("storefs_notification__secret")),
        events: z.string().optional().describe(td("storefs_notification__events")),
        filterPrefix: z.string().optional().describe(td("storefs_notification__filterPrefix")),
        filterSuffix: z.string().optional().describe(td("storefs_notification__filterSuffix")),
        format: z.enum(["native", "aws"]).optional().describe(td("storefs_notification__format")),
        enabled: z.boolean().optional().describe(td("storefs_notification__enabled")),
        retryCount: z.number().int().min(0).optional().describe(td("storefs_notification__retryCount")),
        retryInterval: z.number().int().min(1).optional().describe(td("storefs_notification__retryInterval")),
    }, async ({ bucketId, bucketName, url, secret, events, filterPrefix, filterSuffix, format, enabled, retryCount, retryInterval }) => {
        detectLang({ url });
        const lang = LANG;
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const n = await AdminClient.createNotification(ref, {
                url,
                secret,
                events: events || "s3:ObjectCreated:*",
                filterPrefix: filterPrefix || undefined,
                filterSuffix: filterSuffix || undefined,
                format: format || "native",
                enabled: enabled !== undefined ? enabled : true,
                retryCount,
                retryInterval,
            });
            return { content: [{ type: "text", text: `${tr("notification_created", lang)}: [${n.id}] ${n.url}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update Notification ----
    server.tool("storefs_update_notification", td("storefs_update_notification"), {
        notificationId: z.string().describe(td("storefs_notification__id")),
        url: z.string().url().optional().describe(td("storefs_notification__url")),
        secret: z.string().optional().describe(td("storefs_notification__secret")),
        events: z.string().optional().describe(td("storefs_notification__events")),
        filterPrefix: z.string().optional().describe(td("storefs_notification__filterPrefix")),
        filterSuffix: z.string().optional().describe(td("storefs_notification__filterSuffix")),
        format: z.enum(["native", "aws"]).optional().describe(td("storefs_notification__format")),
        enabled: z.boolean().optional().describe(td("storefs_notification__enabled")),
        retryCount: z.number().int().min(0).optional().describe(td("storefs_notification__retryCount")),
        retryInterval: z.number().int().min(1).optional().describe(td("storefs_notification__retryInterval")),
    }, async ({ notificationId, url, secret, events, filterPrefix, filterSuffix, format, enabled, retryCount, retryInterval }) => {
        detectLang({ notificationId });
        const lang = LANG;
        try {
            const n = await AdminClient.updateNotification(notificationId, {
                url,
                secret,
                events,
                filterPrefix,
                filterSuffix,
                format,
                enabled,
                retryCount,
                retryInterval,
            });
            return { content: [{ type: "text", text: `${tr("notification_updated", lang)}: [${n.id}] ${n.url}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete Notification ----
    server.tool("storefs_delete_notification", td("storefs_delete_notification"), {
        notificationId: z.string().describe(td("storefs_notification__id")),
    }, async ({ notificationId }) => {
        detectLang({ notificationId });
        const lang = LANG;
        try {
            await AdminClient.deleteNotification(notificationId);
            return { content: [{ type: "text", text: `🗑️ ${tr("notification_deleted", lang)}: ${notificationId}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Test Webhook ----
    server.tool("storefs_test_webhook", td("storefs_test_webhook"), {
        url: z.string().url().describe(td("storefs_notification__url")),
        secret: z.string().optional().describe(td("storefs_notification__secret")),
        format: z.enum(["native", "aws"]).optional().describe(td("storefs_notification__format")),
    }, async ({ url, secret, format }) => {
        detectLang({ url });
        const lang = LANG;
        try {
            const result = await AdminClient.testWebhook(url, secret, format);
            if (result.success) {
                return { content: [{ type: "text", text: `✅ ${tr("webhook_test_success", lang)}: HTTP ${result.statusCode}` }] };
            }
            const reason = result.error || `HTTP ${result.statusCode}`;
            return { content: [{ type: "text", text: `❌ ${tr("webhook_test_failed", lang)}: ${reason}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("webhook_test_failed", lang)}: ${e.message}` }] };
        }
    });
}
