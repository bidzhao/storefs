import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { isAuthenticated } from "../auth/admin-auth.js";
import { detectLang, LANG, tr, td } from "../i18n.js";
export function registerTaskTools(server) {
    // ---- List Task Types ----
    server.tool("storefs_list_task_types", td("storefs_list_task_types"), {}, async () => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        try {
            const result = await AdminClient.listTaskTypes();
            const lang = LANG;
            const lines = [`${tr("available_task_types", lang)}:`, ""];
            for (const t of result.types) {
                lines.push(`  📋 ${t.type}${t.description ? ` — ${t.description}` : ""}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", LANG)}: ${e.message}` }] };
        }
    });
    // ---- List Tasks ----
    server.tool("storefs_list_tasks", td("storefs_list_tasks"), {
        page: z.coerce.number().optional().describe(td("storefs_list_tasks__page")),
        pageSize: z.coerce.number().optional().describe(td("storefs_list_tasks__pageSize")),
        status: z.string().optional().describe(td("storefs_list_tasks__status")),
        targetNode: z.string().optional().describe(td("storefs_list_tasks__targetNode")),
    }, async ({ page, pageSize, status, targetNode }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        try {
            const result = await AdminClient.listTasks({ page, pageSize, status, targetNode });
            const lang = LANG;
            const lines = [`${tr("task_list_title", lang)} (${tr("total_count", lang).replace("{n}", String(result.total))}):`, ""];
            for (const t of result.tasks) {
                const statusIcon = taskStatusIcon(t.status, lang);
                lines.push(`  ${statusIcon} [${t.id}] ${t.name} — ${t.status}`);
                lines.push(`     类型: ${t.type}  |  节点: ${t.nodeName || "N/A"}  |  进度: ${t.progress}%`);
                if (t.errorMessage) {
                    lines.push(`     ❌ ${tr("error", lang)}: ${t.errorMessage}`);
                }
                lines.push("");
            }
            if (result.tasks.length === 0) {
                lines.push(`  ${tr("no_tasks_found", lang)}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Get Task ----
    server.tool("storefs_get_task", td("storefs_get_task"), {
        taskId: z.string().describe(td("storefs_get_task__taskId")),
    }, async ({ taskId }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        try {
            const result = await AdminClient.getTask(taskId);
            if (!result.success || !result.task) {
                return { content: [{ type: "text", text: `❌ ${tr("task_not_found", LANG)}` }] };
            }
            const t = result.task;
            const lang = LANG;
            const lines = [`${tr("task_detail_title", lang)}:`, "",
                `  📋 ${tr("id_label", lang)}: ${t.id}`,
                `  ${tr("name_label", lang)}: ${t.name}`,
                `  ${tr("type_label", lang)}: ${t.type}`,
                `  ${tr("status_label", lang)}: ${taskStatusIcon(t.status, lang)} ${t.status}`,
                `  ${tr("node_label", lang)}: ${t.nodeName || "N/A"}`,
                `  ${tr("progress_label", lang)}: ${t.progress}%`,
                `  ${tr("created_at", lang)}: ${t.createdAt}`,
            ];
            if (t.startedAt)
                lines.push(`  ${tr("started_at", lang)}: ${t.startedAt}`);
            if (t.completedAt)
                lines.push(`  ${tr("completed_at", lang)}: ${t.completedAt}`);
            if (t.output)
                lines.push(`  ${tr("output_label", lang)}: ${t.output}`);
            if (t.errorMessage)
                lines.push(`  ❌ ${tr("error", lang)}: ${t.errorMessage}`);
            if (t.params && Object.keys(t.params).length > 0) {
                lines.push(`  ${tr("params_label", lang)}: ${JSON.stringify(t.params, null, 2)}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Create Task (generic) ----
    server.tool("storefs_create_task", td("storefs_create_task"), {
        type: z.string().describe(td("storefs_create_task__type")),
        params: z.record(z.unknown()).describe(td("storefs_create_task__params")),
    }, async ({ type, params }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ type, params });
        const lang = LANG;
        try {
            const result = await AdminClient.createTask(type, params);
            if (!result.success || !result.task) {
                return { content: [{ type: "text", text: `❌ ${tr("create_task_failed", lang)}: ${result.error || result.task?.errorMessage || "unknown"}` }] };
            }
            const t = result.task;
            return {
                content: [{
                        type: "text",
                        text: `${tr("task_created", lang)}\n📋 ${tr("id_label", lang)}: ${t.id}\n${tr("name_label", lang)}: ${t.name}\n${tr("status_label", lang)}: ${taskStatusIcon(t.status, lang)} ${t.status}`
                    }]
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Create Replace Disk Task (typed, with explicit params) ----
    server.tool("storefs_create_replacedisk_task", td("storefs_create_replacedisk_task"), {
        oldDiskPath: z.string().describe(td("storefs_create_replacedisk_task__oldDiskPath")),
        newDiskPath: z.string().describe(td("storefs_create_replacedisk_task__newDiskPath")),
        nodeName: z.string().describe(td("storefs_create_replacedisk_task__nodeName")),
    }, async ({ oldDiskPath, newDiskPath, nodeName }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ oldDiskPath, newDiskPath, nodeName });
        const lang = LANG;
        try {
            const result = await AdminClient.createTask("replacedisk", { oldDiskPath, newDiskPath, nodeName });
            if (!result.success || !result.task) {
                return { content: [{ type: "text", text: `❌ ${tr("create_task_failed", lang)}: ${result.error || result.task?.errorMessage || "unknown"}` }] };
            }
            const t = result.task;
            return {
                content: [{
                        type: "text",
                        text: `${tr("task_created", lang)}\n📋 ${tr("id_label", lang)}: ${t.id}\n${tr("name_label", lang)}: ${t.name}\n${tr("status_label", lang)}: ${taskStatusIcon(t.status, lang)} ${t.status}`
                    }]
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Create Repair Task (typed, with explicit params) ----
    server.tool("storefs_create_repair_task", td("storefs_create_repair_task"), {
        node: z.string().describe(td("storefs_create_repair_task__node")),
        disk: z.string().optional().describe(td("storefs_create_repair_task__disk")),
    }, async ({ node, disk }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ node, disk });
        const lang = LANG;
        try {
            const params = { node };
            if (disk !== undefined)
                params.disk = disk;
            const result = await AdminClient.createTask("repair", params);
            if (!result.success || !result.task) {
                return { content: [{ type: "text", text: `❌ ${tr("create_task_failed", lang)}: ${result.error || result.task?.errorMessage || "unknown"}` }] };
            }
            const t = result.task;
            return {
                content: [{
                        type: "text",
                        text: `${tr("task_created", lang)}\n📋 ${tr("id_label", lang)}: ${t.id}\n${tr("name_label", lang)}: ${t.name}\n${tr("status_label", lang)}: ${taskStatusIcon(t.status, lang)} ${t.status}`
                    }]
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Create Rebalance Task (runs on leader, no params) ----
    server.tool("storefs_create_rebalance_task", td("storefs_create_rebalance_task"), {}, async () => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        const lang = LANG;
        try {
            const result = await AdminClient.createTask("rebalance", {});
            if (!result.success || !result.task) {
                return { content: [{ type: "text", text: `❌ ${tr("create_task_failed", lang)}: ${result.error || result.task?.errorMessage || "unknown"}` }] };
            }
            const t = result.task;
            return {
                content: [{
                        type: "text",
                        text: `${tr("task_created", lang)}\n📋 ${tr("id_label", lang)}: ${t.id}\n${tr("name_label", lang)}: ${t.name}\n${tr("status_label", lang)}: ${taskStatusIcon(t.status, lang)} ${t.status}\n${tr("node_label", lang)}: ${t.nodeName || "leader"}`
                    }]
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Create Decommission Task (migrate all data off a node) ----
    server.tool("storefs_create_decommission_task", td("storefs_create_decommission_task"), {
        nodeName: z.string().describe(td("storefs_create_decommission_task__nodeName")),
        forceRestore: z.boolean().optional().describe(td("storefs_create_decommission_task__forceRestore")),
    }, async ({ nodeName, forceRestore }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        const lang = LANG;
        try {
            const params = { nodeName, forceRestore: forceRestore ?? false };
            const result = await AdminClient.createTask("decommission", params);
            if (!result.success || !result.task) {
                return { content: [{ type: "text", text: `❌ ${tr("create_task_failed", lang)}: ${result.error || result.task?.errorMessage || "unknown"}` }] };
            }
            const t = result.task;
            return {
                content: [{
                        type: "text",
                        text: `${tr("task_created", lang)}\n📋 ${tr("id_label", lang)}: ${t.id}\n${tr("name_label", lang)}: ${t.name}\n${tr("status_label", lang)}: ${taskStatusIcon(t.status, lang)} ${t.status}\n${tr("node_label", lang)}: ${t.nodeName || "any"}`
                    }]
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Cancel Task ----
    server.tool("storefs_cancel_task", td("storefs_cancel_task"), {
        taskId: z.string().describe(td("storefs_cancel_task__taskId")),
    }, async ({ taskId }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ taskId });
        const lang = LANG;
        try {
            const result = await AdminClient.cancelTask(taskId);
            if (result.success) {
                return { content: [{ type: "text", text: `${tr("task_cancelled", lang)} [${taskId}]` }] };
            }
            return { content: [{ type: "text", text: `❌ ${tr("cancel_failed", lang)}: ${taskId}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Delete Task ----
    server.tool("storefs_delete_task", td("storefs_delete_task"), {
        taskId: z.string().describe(td("storefs_delete_task__taskId")),
    }, async ({ taskId }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ taskId });
        const lang = LANG;
        try {
            await AdminClient.deleteTask(taskId);
            return { content: [{ type: "text", text: `${tr("task_deleted", lang)} [${taskId}]` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Cleanup Tasks ----
    server.tool("storefs_cleanup_tasks", td("storefs_cleanup_tasks"), {
        days: z.coerce.number().optional().describe(td("storefs_cleanup_tasks__days")),
    }, async ({ days }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ days });
        const lang = LANG;
        try {
            const result = await AdminClient.cleanupTasks(days);
            if (result.success) {
                return { content: [{ type: "text", text: `${tr("cleanup_tasks_success", lang)}: ${result.message}` }] };
            }
            return { content: [{ type: "text", text: `❌ ${tr("cleanup_failed", lang)}: ${result.error || "unknown"}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Force Cancel Task (super_admin) ----
    server.tool("storefs_force_cancel_task", td("storefs_force_cancel_task"), {
        taskId: z.string().describe(td("storefs_force_cancel_task__taskId")),
    }, async ({ taskId }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ taskId });
        const lang = LANG;
        try {
            const result = await AdminClient.forceCancelTask(taskId);
            if (result.success) {
                return { content: [{ type: "text", text: `${tr("task_force_cancelled", lang)} [${taskId}]` }] };
            }
            return { content: [{ type: "text", text: `❌ ${tr("cancel_failed", lang)}: ${taskId}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Backfill Target Node (super_admin) ----
    server.tool("storefs_backfill_target_node", td("storefs_backfill_target_node"), {}, async () => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        const lang = LANG;
        try {
            const result = await AdminClient.backfillTargetNode();
            return {
                content: [{
                        type: "text",
                        text: `${tr("backfill_target_title", lang)}\n  ${tr("backfill_target_filled", lang)}: ${result.filled}\n  ${tr("backfill_target_blocked", lang)}: ${result.blocked}`,
                    }],
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Latest Task by Target Node ----
    server.tool("storefs_get_latest_task_by_target_node", td("storefs_get_latest_task_by_target_node"), {
        targetNode: z.string().describe(td("storefs_get_latest_task_by_target_node__targetNode")),
    }, async ({ targetNode }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ targetNode });
        const lang = LANG;
        try {
            const result = await AdminClient.listTasksByTargetNode(targetNode);
            if (!result.success || result.tasks.length === 0) {
                return { content: [{ type: "text", text: `${tr("no_tasks_found", lang)} (${targetNode})` }] };
            }
            const t = result.tasks[0];
            return {
                content: [{
                        type: "text",
                        text: `${tr("latest_task_for_node", lang)} ${targetNode}:\n  ${taskStatusIcon(t.status, lang)} [${t.id}] ${t.name} — ${t.status}\n  ${tr("progress_label", lang)}: ${t.progress}%`,
                    }],
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
}
// ---- Helpers ----
function taskStatusIcon(status, _lang) {
    switch (status) {
        case "pending":
            return "⏳";
        case "running":
            return "🔄";
        case "completed":
            return "✅";
        case "failed":
            return "❌";
        case "cancelled":
            return "⛔";
        default:
            return "❓";
    }
}
