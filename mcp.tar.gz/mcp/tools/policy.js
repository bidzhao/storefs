import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { detectLang, LANG, tr, td } from "../i18n.js";
export function registerPolicyTools(server) {
    // ---- List Policies ----
    server.tool("storefs_list_policies", td("storefs_list_policies"), {
        page: z.number().optional(),
        pageSize: z.number().optional(),
    }, async ({ page, pageSize }) => {
        try {
            const data = await AdminClient.listPolicies({ page, pageSize });
            const lines = [`${tr("policy_list_title")} (${tr("total_policies").replace("{n}", String(data.total))}):`, ""];
            for (const p of data.policies) {
                const detail = p.type === "replicas"
                    ? tr("replicas_count").replace("{n}", String(p.replicas))
                    : tr("ec_detail").replace("{d}", String(p.dataShards)).replace("{p}", String(p.parityShards));
                const typeLabel = p.type === "replicas" ? tr("policy_type_replicas") : tr("policy_type_ec");
                lines.push(`  [${p.id}] ${p.name}`);
                lines.push(`     ${typeLabel}  |  ${detail}`);
                lines.push(`     ${tr("created_at_label")}: ${p.createdAt}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Policy ----
    server.tool("storefs_get_policy", td("storefs_get_policy"), { policyId: z.string().describe(td("storefs_get_policy__policyId")) }, async ({ policyId }) => {
        try {
            const p = await AdminClient.getPolicy(policyId);
            const detail = p.type === "replicas"
                ? `  ${tr("replicas_count").replace("{n}", String(p.replicas))}`
                : `  ${tr("ec_detail").replace("{d}", String(p.dataShards)).replace("{p}", String(p.parityShards))}`;
            const typeLabel = p.type === "replicas" ? tr("policy_type_replicas") : tr("policy_type_ec");
            return { content: [{ type: "text", text: [
                            `Policy:`,
                            `  ID: ${p.id}`,
                            `  Name: ${p.name}`,
                            `  Type: ${typeLabel}`,
                            detail,
                            `  ${tr("created_at_label")}: ${p.createdAt}`,
                        ].join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create Policy ----
    server.tool("storefs_create_policy", td("storefs_create_policy"), {
        name: z.string().describe(td("storefs_create_policy__name")),
        type: z.enum(["replicas", "ec"]).describe(td("storefs__policyType")),
        replicas: z.number().optional().describe(td("storefs__policyReplicas")),
        dataShards: z.number().optional().describe(td("storefs__policyDataShards")),
        parityShards: z.number().optional().describe(td("storefs__policyParityShards")),
    }, async ({ name, type, replicas, dataShards, parityShards }) => {
        detectLang({ name });
        const lang = LANG;
        if (type === "replicas" && (replicas === undefined || replicas < 1)) {
            return { content: [{ type: "text", text: "❌ replicas is required and must be >= 1 for replicas type" }] };
        }
        if (type === "ec" && (dataShards === undefined || parityShards === undefined)) {
            return { content: [{ type: "text", text: "❌ dataShards and parityShards are required for EC type" }] };
        }
        try {
            const p = await AdminClient.createPolicy({ name, type, replicas, dataShards, parityShards });
            return { content: [{ type: "text", text: `${tr("policy_created", lang)}: [${p.id}] ${p.name}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update Policy ----
    server.tool("storefs_update_policy", td("storefs_update_policy"), {
        policyId: z.string().describe(td("storefs__policyId")),
        name: z.string().optional().describe(td("storefs__newName")),
        type: z.enum(["replicas", "ec"]).optional().describe(td("storefs__newType")),
        replicas: z.number().optional().describe(td("storefs__newReplicas")),
        dataShards: z.number().optional().describe(td("storefs__newDataShards")),
        parityShards: z.number().optional().describe(td("storefs__newParityShards")),
    }, async ({ policyId, name, type, replicas, dataShards, parityShards }) => {
        try {
            await AdminClient.updatePolicy(policyId, { name, type, replicas, dataShards, parityShards });
            return { content: [{ type: "text", text: `${tr("policy_updated")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete Policy ----
    server.tool("storefs_delete_policy", td("storefs_delete_policy"), { policyId: z.string().describe(td("storefs__policyId")) }, async ({ policyId }) => {
        try {
            await AdminClient.deletePolicy(policyId);
            return { content: [{ type: "text", text: tr("policy_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
}
