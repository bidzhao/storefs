import { z } from "zod";
import { loadConfig } from "../config.js";
import * as AdminClient from "../api/admin-client.js";
import { setAuth, setPATAuth, clearAuth, getAuthHeader, getCurrentUser, isAuthenticated, setPendingMFA, clearPendingMFA, getMFARemainingAttempts, recordMFAFailure, resetMFAFailures } from "../auth/admin-auth.js";
import { detectLang, LANG, tr, td } from "../i18n.js";
export function registerSystemTools(server) {
    // ---- Health ----
    server.tool("storefs_health", td("storefs_health"), {}, async () => {
        try {
            const res = await fetch(`${loadConfig().adminUrl.replace(/\/+$/, "")}/api/health`);
            const text = await res.text();
            return { content: [{ type: "text", text: text }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("cluster_unreachable")}: ${e.message}` }] };
        }
    });
    // ---- Login ----
    server.tool("storefs_login", td("storefs_login"), {
        username: z.string().describe(td("storefs_login__username")),
        password: z.string().describe(td("storefs_login__password")),
        mfaCode: z.string().optional().describe(td("storefs_login__mfaCode")),
    }, async ({ username, password, mfaCode }) => {
        detectLang({ username, password });
        const lang = LANG;
        try {
            const result = await AdminClient.login(username, password);
            if (!result.success) {
                return { content: [{ type: "text", text: `${tr("login_failed", lang)}: ${result.message}` }] };
            }
            if (result.mfaRequired && result.tempToken) {
                // MFA is required
                if (!mfaCode) {
                    // No MFA code provided — store tempToken and ask user to retry
                    setPendingMFA(username, result.tempToken);
                    return {
                        content: [{
                                type: "text",
                                text: [
                                    `⚠️ ${tr("mfa_code_required", lang)}`,
                                    ``,
                                    tr("mfa_retry", lang).replace("{username}", username),
                                    `  ${tr("mfa_attempts_remaining", lang).replace("{n}", String(getMFARemainingAttempts(username)))}`,
                                ].join("\n"),
                            }],
                    };
                }
                // MFA code provided — verify it
                try {
                    const mfaResult = await AdminClient.verifyMFALogin(result.tempToken, mfaCode);
                    // Success — clear MFA state and set auth
                    clearPendingMFA(username);
                    setAuth(mfaResult.token, mfaResult);
                    const lines = [tr("mfa_login_success", lang), ""];
                    lines.push(`${tr("username_label", lang)}: ${mfaResult.name}`);
                    lines.push(`${tr("role_label", lang)}: ${mfaResult.role}`);
                    lines.push(`${tr("group_name_label", lang)}: ${mfaResult.groupName || tr("no_group", lang)}`);
                    if (mfaResult.mustChangePassword) {
                        lines.push("");
                        lines.push(`⚠️  ${tr("force_changepwd", lang)}, ${tr("password_changed", lang)}`);
                    }
                    return { content: [{ type: "text", text: lines.join("\n") }] };
                }
                catch (mfaError) {
                    // MFA verification failed
                    const lockedOut = recordMFAFailure(username);
                    if (lockedOut) {
                        return {
                            content: [{
                                    type: "text",
                                    text: `❌ ${tr("mfa_locked_out", lang)}`,
                                }],
                        };
                    }
                    return {
                        content: [{
                                type: "text",
                                text: `❌ ${tr("mfa_verify_failed", lang)}: ${mfaError.message}\n${tr("mfa_attempts_remaining", lang).replace("{n}", String(getMFARemainingAttempts(username)))}`,
                            }],
                    };
                }
            }
            // Normal login (no MFA)
            setAuth(result.token, result);
            const lines = [tr("login_success", lang), ""];
            lines.push(`${tr("username_label", lang)}: ${result.name}`);
            lines.push(`${tr("role_label", lang)}: ${result.role}`);
            lines.push(`${tr("group_name_label", lang)}: ${result.groupName || tr("no_group", lang)}`);
            if (result.mustChangePassword) {
                lines.push("");
                lines.push(`⚠️  ${tr("force_changepwd", lang)}, ${tr("password_changed", lang)}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            // On any error, clear MFA state for this user
            clearPendingMFA(username);
            resetMFAFailures(username);
            return { content: [{ type: "text", text: `${tr("login_failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Login with PAT ----
    server.tool("storefs_login_with_pat", td("storefs_login_with_pat"), {
        pat: z.string().describe(td("storefs_login_with_pat__pat")),
    }, async ({ pat }) => {
        detectLang({ pat });
        const lang = LANG;
        try {
            const result = await AdminClient.loginWithPAT(pat);
            setPATAuth(result.token, result);
            const lines = [tr("login_success", lang), ""];
            lines.push(`${tr("username_label", lang)}: ${result.name}`);
            lines.push(`${tr("role_label", lang)}: ${result.role}`);
            lines.push(`${tr("group_name_label", lang)}: ${result.groupName || tr("no_group", lang)}`);
            lines.push(`${tr("auth_method_label", lang)}: PAT`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `${tr("login_failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Logout ----
    server.tool("storefs_logout", td("storefs_logout"), {}, async () => {
        try {
            await AdminClient.logout();
        }
        catch (e) {
            // Backend call may fail (e.g. token already expired);
            // still clear local state regardless.
        }
        clearAuth();
        return { content: [{ type: "text", text: tr("logout_ok") }] };
    });
    // ---- Whoami ----
    server.tool("storefs_whoami", td("storefs_whoami"), {}, async () => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        const u = getCurrentUser();
        const lines = [
            `${tr("current_user")}:`,
            `  ID: ${u.id}`,
            `  ${tr("username_label")}: ${u.name}`,
            `  ${tr("role_label")}: ${u.role}`,
            `  ${tr("group_id_label")}: ${u.groupId}`,
            `  ${tr("group_name_label")}: ${u.groupName || tr("no_group")}`,
        ];
        return { content: [{ type: "text", text: lines.join("\n") }] };
    });
    // ---- Cluster Status ----
    server.tool("storefs_cluster_status", td("storefs_cluster_status"), {}, async () => {
        try {
            const nodes = await AdminClient.getAllNodeStatus();
            let nodeStatusMap = new Map();
            try {
                const nodeStatusResult = await AdminClient.listNodeStatus();
                for (const status of nodeStatusResult.statuses) {
                    nodeStatusMap.set(status.nodeName, status.status);
                }
            }
            catch {
                // If node status API fails, just continue without taint info
            }
            const lang = LANG;
            const lines = [`${tr("cluster_nodes", lang)} (${tr("total_nodes", lang).replace("{n}", String(nodes.length))}):`, ""];
            for (const node of nodes) {
                const taintStatus = nodeStatusMap.get(node.name);
                const statusLabel = taintStatus === "taint"
                    ? " ❌ " + tr("node_status_taint", lang)
                    : " ✅ " + tr("node_status_active", lang);
                lines.push(`  📦 ${node.name} (${node.ip}:${node.port})${statusLabel}`);
                lines.push(`     S3: ${node.s3.host}:${node.s3.port}`);
                for (const disk of node.disks || []) {
                    const totalGB = (disk.totalCapacity / 1e9).toFixed(1);
                    const usedGB = (disk.usedCapacity / 1e9).toFixed(1);
                    const pct = disk.totalCapacity > 0 ? ((disk.usedCapacity / disk.totalCapacity) * 100).toFixed(1) : "?";
                    lines.push(`     💾 ${disk.path}: ${usedGB}GB / ${totalGB}GB (${pct}%)`);
                }
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed")}: ${e.message}` }] };
        }
    });
    // ---- Node Metrics ----
    server.tool("storefs_node_metrics", td("storefs_node_metrics"), {
        filter: z.string().optional().describe(td("storefs_node_metrics__filter")),
    }, async ({ filter }) => {
        try {
            let metrics = await AdminClient.getMetrics();
            if (filter) {
                metrics = metrics
                    .split("\n")
                    .filter((l) => l.toLowerCase().includes(filter.toLowerCase()))
                    .join("\n");
            }
            const lines = metrics.split("\n").slice(0, 80);
            if (lines.length < metrics.split("\n").length) {
                lines.push(tr("metrics_truncated"));
            }
            return { content: [{ type: "text", text: lines.join("\n") || tr("metrics_filter") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed")}: ${e.message}` }] };
        }
    });
    // ---- Change Password ----
    server.tool("storefs_change_password", td("storefs_change_password"), {
        oldPassword: z.string().describe(td("storefs_change_password__oldPassword")),
        newPassword: z.string().describe(td("storefs_change_password__newPassword")),
    }, async ({ oldPassword, newPassword }) => {
        detectLang({ oldPassword, newPassword });
        const lang = LANG;
        try {
            const cfg = loadConfig();
            const res = await fetch(`${cfg.adminUrl.replace(/\/+$/, "")}/api/auth/change-password`, {
                method: "PUT",
                headers: { Authorization: getAuthHeader(), "Content-Type": "application/json" },
                body: JSON.stringify({ oldPassword, newPassword }),
            });
            const data = await res.json();
            if (data.success) {
                // Attempt re-login BEFORE clearing auth, so a failure doesn't leave the user logged out
                const u = getCurrentUser();
                if (u) {
                    try {
                        const loginRes = await AdminClient.login(u.name, newPassword);
                        clearAuth();
                        setAuth(loginRes.token, loginRes);
                    }
                    catch {
                        // Re-login failed — keep old session alive
                        return { content: [{ type: "text", text: `${tr("password_changed", lang)}\n⚠️ Session re-login failed, please login again manually.` }] };
                    }
                }
                return { content: [{ type: "text", text: tr("password_changed", lang) }] };
            }
            return { content: [{ type: "text", text: `❌ ${data.error || data.message || tr("failed", lang)}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- List Node Status ----
    server.tool("storefs_list_node_status", td("storefs_list_node_status"), {}, async () => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        try {
            const result = await AdminClient.listNodeStatus();
            const lang = LANG;
            const lines = [tr("node_status_list_title", lang), ""];
            for (const status of result.statuses) {
                const statusLabel = status.status === "taint"
                    ? "❌ " + tr("node_status_taint", lang)
                    : "✅ " + tr("node_status_active", lang);
                lines.push(`📦 ${status.nodeName}`);
                lines.push(`   ${tr("node_taint_status", lang)}: ${statusLabel}`);
                lines.push(`   ${tr("node_operator", lang)}: ${status.operator}`);
                lines.push(`   ${tr("node_last_update", lang)}: ${status.lastUpdateAt}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Update Node Status ----
    server.tool("storefs_update_node_status", td("storefs_update_node_status"), {
        nodeName: z.string().describe(td("storefs_update_node_status__nodeName")),
        status: z.enum(["active", "taint"]).describe(td("storefs_update_node_status__status")),
    }, async ({ nodeName, status }) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        detectLang({ nodeName, status });
        const lang = LANG;
        try {
            await AdminClient.updateNodeStatus(nodeName, status);
            const statusLabel = status === "taint"
                ? "❌ " + tr("node_status_taint", lang)
                : "✅ " + tr("node_status_active", lang);
            return {
                content: [{
                        type: "text",
                        text: `${tr("node_status_updated", lang)}\n📦 ${nodeName}\n${tr("node_taint_status", lang)}: ${statusLabel}`
                    }]
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Raft Leader ----
    server.tool("storefs_raft_leader", td("storefs_raft_leader"), {}, async () => {
        try {
            const result = await AdminClient.getRaftLeader();
            const lang = LANG;
            const lines = [tr("raft_leader_title", lang)];
            lines.push(`  ${tr("raft_leader_id", lang)}: ${result.leader_id || tr("raft_no_leader", lang)}`);
            if (result.leader_id) {
                lines.push(`  ${tr("raft_leader_addr", lang)}: ${result.leader_addr}`);
                lines.push(`  ${tr("raft_this_node_is_leader", lang)}: ${result.is_leader ? tr("yes", lang) : tr("no", lang)}`);
            }
            lines.push(`  ${tr("raft_state", lang)}: ${result.state}`);
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Gateway Status ----
    server.tool("storefs_gateway_status", td("storefs_gateway_status"), {}, async () => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        const lang = LANG;
        try {
            const status = await AdminClient.getGatewayStatus();
            const lines = [tr("gateway_status_title", lang), ""];
            // NFS section
            if (status.nfs) {
                const nfsLabel = status.nfs.enabled ? (status.nfs.running ? tr("running", lang) : tr("stopped", lang)) : tr("disabled", lang);
                lines.push(`📁 NFS ${tr("gateway", lang)}: ${nfsLabel}`);
                if (status.nfs.enabled) {
                    lines.push(`   ${tr("gateway_port", lang)}: ${status.nfs.port}`);
                    lines.push(`   ${tr("gateway_export_path", lang)}: ${status.nfs.exportPath}`);
                    lines.push(`   ${tr("gateway_auth_type", lang)}: ${status.nfs.authType}`);
                    lines.push(`   ${tr("gateway_map_user", lang)}: ${status.nfs.mapUser}`);
                    lines.push(`   ${tr("gateway_read_only", lang)}: ${status.nfs.readOnly ? tr("yes", lang) : tr("no", lang)}`);
                }
                lines.push("");
            }
            else {
                lines.push(`📁 NFS ${tr("gateway", lang)}: ${tr("not_configured", lang)}`);
                lines.push("");
            }
            // SMB section
            if (status.smb) {
                const smbLabel = status.smb.enabled ? (status.smb.running ? tr("running", lang) : tr("stopped", lang)) : tr("disabled", lang);
                lines.push(`🔗 SMB ${tr("gateway", lang)}: ${smbLabel}`);
                if (status.smb.enabled) {
                    lines.push(`   ${tr("gateway_port", lang)}: ${status.smb.port}`);
                    lines.push(`   ${tr("gateway_share_name", lang)}: ${status.smb.shareName}`);
                    lines.push(`   ${tr("gateway_server_name", lang)}: ${status.smb.serverName}`);
                    lines.push(`   ${tr("gateway_workgroup", lang)}: ${status.smb.workgroup}`);
                    lines.push(`   ${tr("gateway_guest_allowed", lang)}: ${status.smb.guestAllowed ? tr("yes", lang) : tr("no", lang)}`);
                    lines.push(`   ${tr("gateway_read_only", lang)}: ${status.smb.readOnly ? tr("yes", lang) : tr("no", lang)}`);
                    lines.push(`   ${tr("gateway_map_user", lang)}: ${status.smb.mapUser}`);
                }
                lines.push("");
            }
            else {
                lines.push(`🔗 SMB ${tr("gateway", lang)}: ${tr("not_configured", lang)}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    });
    // ---- Audit Logs ----
    server.tool("storefs_list_audit_logs", td("storefs_list_audit_logs"), {
        page: z.number().optional().describe(td("storefs_list_audit_logs__page")),
        pageSize: z.number().optional().describe(td("storefs_list_audit_logs__pageSize")),
        sortBy: z.enum(["timestamp", "duration_ms", "status_code", "operation_type", "user_identity"]).optional().describe(td("storefs_list_audit_logs__sortBy")),
        sortOrder: z.enum(["asc", "desc"]).optional().describe(td("storefs_list_audit_logs__sortOrder")),
        startTime: z.string().optional().describe(td("storefs_list_audit_logs__startTime")),
        endTime: z.string().optional().describe(td("storefs_list_audit_logs__endTime")),
        userIdentity: z.string().optional().describe(td("storefs_list_audit_logs__userIdentity")),
        operationType: z.string().optional().describe(td("storefs_list_audit_logs__operationType")),
        statusCode: z.number().optional().describe(td("storefs_list_audit_logs__statusCode")),
        bucketName: z.string().optional().describe(td("storefs_list_audit_logs__bucketName")),
        resourceType: z.string().optional().describe(td("storefs_list_audit_logs__resourceType")),
        sourceIp: z.string().optional().describe(td("storefs_list_audit_logs__sourceIp")),
        httpMethod: z.string().optional().describe(td("storefs_list_audit_logs__httpMethod")),
        requestId: z.string().optional().describe(td("storefs_list_audit_logs__requestId")),
        errorCode: z.string().optional().describe(td("storefs_list_audit_logs__errorCode")),
    }, async (params) => {
        try {
            const lang = detectLang(params || {});
            const result = await AdminClient.listAuditLogs(params);
            const lines = [];
            lines.push(`📋 ${tr("audit_logs_title", lang)}`);
            lines.push(`   ${tr("total", lang)}: ${result.total}  |  ${tr("page", lang)}: ${result.page}/${result.pageSize}`);
            lines.push("");
            for (const entry of result.auditLogs) {
                lines.push(`[${entry.timestamp}] ${entry.operationType} — ${entry.userIdentity} (${entry.statusCode}, ${entry.durationMs}ms)`);
                lines.push(`   ${entry.httpMethod} ${entry.path}`);
                if (entry.bucketName)
                    lines.push(`   ${tr("bucket", lang)}: ${entry.bucketName}`);
                if (entry.objectKey)
                    lines.push(`   ${tr("object", lang)}: ${entry.objectKey}`);
                if (entry.errorCode)
                    lines.push(`   ⚠️ ${tr("error", lang)}: ${entry.errorCode}`);
                lines.push(`   ${tr("request_id", lang)}: ${entry.requestId}`);
                lines.push("");
            }
            if (result.auditLogs.length === 0) {
                lines.push(tr("no_data", lang));
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", LANG)}: ${e.message}` }] };
        }
    });
    // ---- Lifecycle Config ----
    server.tool("storefs_get_lifecycle_config", td("storefs_get_lifecycle_config"), {}, async () => {
        detectLang({});
        const lang = LANG;
        try {
            const config = await AdminClient.getLifecycleConfig();
            const enabled = config.enabled ? tr("enabled", lang) : tr("disabled", lang);
            return { content: [{ type: "text", text: `${tr("lifecycle_scanner", lang)}: ${enabled}\n${tr("scan_interval", lang)}: ${config.scan_interval}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    server.tool("storefs_put_lifecycle_config", td("storefs_put_lifecycle_config"), {
        enabled: z.boolean().describe(td("storefs_put_lifecycle_config__enabled")),
        scanInterval: z.string().optional().describe(td("storefs_put_lifecycle_config__scanInterval")),
    }, async ({ enabled, scanInterval }) => {
        detectLang({ enabled, scanInterval });
        const lang = LANG;
        try {
            const body = { enabled };
            if (scanInterval)
                body.scan_interval = scanInterval;
            await AdminClient.putLifecycleConfig(body);
            return { content: [{ type: "text", text: tr("lifecycle_config_updated", lang) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
}
