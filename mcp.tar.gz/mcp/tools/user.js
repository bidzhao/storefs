import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { detectLang, LANG, tr, td } from "../i18n.js";
export function registerUserTools(server) {
    // ---- List Users ----
    server.tool("storefs_list_users", td("storefs_list_users"), {
        groupId: z.string().optional().describe(td("storefs_list_users__groupId")),
        page: z.number().optional().describe(td("storefs_list_users__page")),
        pageSize: z.number().optional().describe(td("storefs_list_users__pageSize")),
        sortBy: z.enum(["created_at", "name"]).optional().describe(td("storefs_list_users__sortBy")),
        sortOrder: z.enum(["asc", "desc"]).optional().describe(td("storefs_list_users__sortOrder")),
    }, async ({ groupId, page, pageSize, sortBy, sortOrder }) => {
        try {
            const data = await AdminClient.listUsers({ groupId, page, pageSize, sortBy, sortOrder });
            const lines = [`${tr("user_list_title")} (${tr("total_users").replace("{n}", String(data.total))}):`, ""];
            for (const u of data.users) {
                lines.push(`  [${u.id}] ${u.name}`);
                if (u.email)
                    lines.push(`     ${tr("email_label")}: ${u.email}`);
                lines.push(`     ${tr("role_label")}: ${u.role}  |  ${tr("group_name_label")}: ${u.groupName || tr("no_group")}`);
                lines.push(`     ${tr("created_at_label")}: ${u.created_at}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get User ----
    server.tool("storefs_get_user", td("storefs_get_user"), { userId: z.string().describe(td("storefs_get_user__userId")) }, async ({ userId }) => {
        try {
            const u = await AdminClient.getUser(userId);
            const emailLine = u.email ? `  ${tr("email_label")}: ${u.email}` : "";
            return {
                content: [{
                        type: "text",
                        text: [
                            `${tr("user_detail_title")}:`,
                            `  ID: ${u.id}`,
                            `  ${tr("username_label")}: ${u.name}`,
                            emailLine,
                            `  ${tr("role_label")}: ${u.role}`,
                            `  ${tr("group_id_label")}: ${u.groupId}`,
                            `  ${tr("group_name_label")}: ${u.groupName || tr("no_group")}`,
                            `  ${tr("force_changepwd")}: ${u.mustChangePassword ? tr("yes") : tr("no")}`,
                            `  ${tr("created_at_label")}: ${u.created_at}`,
                        ].filter(Boolean).join("\n"),
                    }],
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create User ----
    server.tool("storefs_create_user", td("storefs_create_user"), {
        username: z.string().describe(td("storefs_create_user__username")),
        password: z.string().describe(td("storefs_create_user__password")),
        email: z.string().describe(td("storefs_create_user__email")),
        role: z.enum(["super_admin", "group_admin", "user"]).describe(td("storefs_create_user__role")),
        groupId: z.string().optional().describe(td("storefs_create_user__groupId")),
        mustChangePassword: z.boolean().optional().describe(td("storefs_create_user__mustChangePassword")),
    }, async ({ username, password, email, role, groupId, mustChangePassword }) => {
        detectLang({ username });
        const lang = LANG;
        try {
            const u = await AdminClient.createUser({ username, password, email, role, groupId, mustChangePassword });
            const keys = await AdminClient.getAccessKeys(u.id);
            const emailLine = u.email ? `\n  ${tr("email_label", lang)}: ${u.email}` : "";
            const keyInfo = keys.length > 0
                ? `\n\n${tr("access_keys_title", lang)}:\n  AK: ${keys[0].accessKey}\n  SK: ${keys[0].secretKey}`
                : "";
            return { content: [{ type: "text", text: `${tr("user_created", lang)}\n  ID: ${u.id}\n  ${tr("username_label", lang)}: ${u.name}${emailLine}\n  ${tr("role_label", lang)}: ${u.role}${keyInfo}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update User ----
    server.tool("storefs_update_user", td("storefs_update_user"), {
        userId: z.string().describe(td("storefs_update_user__userId")),
        username: z.string().optional().describe(td("storefs_update_user__username")),
        email: z.string().optional().describe(td("storefs_update_user__email")),
        role: z.string().optional().describe(td("storefs_update_user__role")),
        groupId: z.string().optional().describe(td("storefs_update_user__groupId")),
    }, async ({ userId, username, email, role, groupId }) => {
        try {
            const u = await AdminClient.updateUser(userId, { username, email, role, groupId });
            return { content: [{ type: "text", text: `${tr("user_updated")}: ${u.name}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete User ----
    server.tool("storefs_delete_user", td("storefs_delete_user"), { userId: z.string().describe(td("storefs_delete_user__userId")) }, async ({ userId }) => {
        try {
            await AdminClient.deleteUser(userId);
            return { content: [{ type: "text", text: tr("user_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Access Keys ----
    server.tool("storefs_get_access_keys", td("storefs_get_access_keys"), { userId: z.string().describe(td("storefs_get_access_keys__userId")) }, async ({ userId }) => {
        try {
            const keys = await AdminClient.getAccessKeys(userId);
            if (keys.length === 0) {
                return { content: [{ type: "text", text: tr("no_access_keys") }] };
            }
            const lines = keys.map((k) => `  AccessKey: ${k.accessKey}\n  SecretKey: ${k.secretKey}\n  ${tr("created_at_label")}: ${k.createdAt}`);
            return { content: [{ type: "text", text: `${tr("access_keys_title")}:\n\n${lines.join("\n\n")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Rotate Access Keys ----
    server.tool("storefs_rotate_access_keys", td("storefs_rotate_access_keys"), { userId: z.string().describe(td("storefs_rotate_access_keys__userId")) }, async ({ userId }) => {
        try {
            const key = await AdminClient.rotateAccessKeys(userId);
            return { content: [{ type: "text", text: `${tr("keys_rotated")}\n  AccessKey: ${key.accessKey}\n  SecretKey: ${key.secretKey}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Reset Password ----
    server.tool("storefs_reset_password", td("storefs_reset_password"), {
        userId: z.string().describe(td("storefs_reset_password__userId")),
        password: z.string().describe(td("storefs_reset_password__password")),
        mustChangePassword: z.boolean().optional().describe(td("storefs_reset_password__mustChangePassword")),
    }, async ({ userId, password, mustChangePassword }) => {
        try {
            await AdminClient.resetPassword(userId, password, mustChangePassword);
            return { content: [{ type: "text", text: tr("password_reset") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Disable MFA ----
    server.tool("storefs_disable_user_mfa", td("storefs_disable_user_mfa"), {
        userId: z.string().describe(td("storefs_disable_user_mfa__userId")),
    }, async ({ userId }) => {
        try {
            await AdminClient.disableUserMFA(userId);
            return { content: [{ type: "text", text: tr("mfa_disabled") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List Groups ----
    server.tool("storefs_list_groups", td("storefs_list_groups"), { page: z.number().optional(), pageSize: z.number().optional() }, async ({ page, pageSize }) => {
        try {
            const data = await AdminClient.listGroups({ page, pageSize });
            const lines = [`${tr("group_list_title")} (${tr("total_groups").replace("{n}", String(data.total))}):`, ""];
            for (const g of data.groups) {
                lines.push(`  [${g.id}] ${g.name}`);
                const dp = g.defaultPolicyName
                    ? `${tr("default_policy")}: ${g.defaultPolicyName} (ID: ${g.defaultPolicyId})`
                    : `${tr("default_policy")}: ${tr("no_default_policy")}`;
                lines.push(`    ${dp}`);
                lines.push(`    ${tr("created_at_label")}: ${g.created_at}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Group ----
    server.tool("storefs_get_group", td("storefs_get_group"), { groupId: z.string().describe(td("storefs_get_group__groupId")) }, async ({ groupId }) => {
        try {
            const g = await AdminClient.getGroup(groupId);
            const lines = [
                `Group:`,
                `  ID: ${g.id}`,
                `  Name: ${g.name}`,
                g.defaultPolicyName
                    ? `  ${tr("default_policy")}: ${g.defaultPolicyName} (ID: ${g.defaultPolicyId})`
                    : `  ${tr("default_policy")}: ${tr("no_default_policy")}`,
                `  ${tr("created_at_label")}: ${g.created_at}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create Group ----
    server.tool("storefs_create_group", td("storefs_create_group"), {
        name: z.string().describe(td("storefs_create_group__name")),
        defaultPolicyId: z.string().optional().describe(td("storefs_create_group__defaultPolicyId")),
    }, async ({ name, defaultPolicyId }) => {
        detectLang({ name });
        const lang = LANG;
        try {
            const g = await AdminClient.createGroup(name, defaultPolicyId);
            return { content: [{ type: "text", text: `${tr("group_created", lang)}: [${g.id}] ${g.name}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update Group ----
    server.tool("storefs_update_group", td("storefs_update_group"), {
        groupId: z.string().describe(td("storefs_update_group__groupId")),
        name: z.string().optional().describe(td("storefs_update_group__name")),
        defaultPolicyId: z.string().optional().describe(td("storefs_update_group__defaultPolicyId")),
    }, async ({ groupId, name, defaultPolicyId }) => {
        try {
            const body = {};
            if (name !== undefined)
                body.name = name;
            if (defaultPolicyId !== undefined)
                body.defaultPolicyId = defaultPolicyId;
            await AdminClient.updateGroup(groupId, body);
            return { content: [{ type: "text", text: `${tr("group_updated")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete Group ----
    server.tool("storefs_delete_group", td("storefs_delete_group"), { groupId: z.string().describe(td("storefs_delete_group__groupId")) }, async ({ groupId }) => {
        try {
            await AdminClient.deleteGroup(groupId);
            return { content: [{ type: "text", text: tr("group_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
}
