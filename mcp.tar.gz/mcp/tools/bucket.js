import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { detectLang, LANG, tr, td, formatSize } from "../i18n.js";
import { bucketNameParam, bucketRef } from "../utils/bucket-ref.js";
export function registerBucketTools(server) {
    // ---- List Buckets ----
    server.tool("storefs_list_buckets", td("storefs_list_buckets"), {
        userId: z.string().optional().describe(td("storefs_list_buckets__userId")),
        groupId: z.string().optional().describe(td("storefs_list_buckets__groupId")),
        page: z.number().optional(),
        pageSize: z.number().optional(),
    }, async ({ userId, groupId, page, pageSize }) => {
        try {
            const data = await AdminClient.listBuckets({ userId, groupId, page, pageSize });
            const lines = [`${tr("bucket_list_title")} (${tr("total_buckets").replace("{n}", String(data.total))}):`, ""];
            for (const b of data.buckets) {
                const verStr = b.versioning || tr("not_enabled");
                lines.push(`  [${b.id}] ${b.name}`);
                lines.push(`    ${tr("policy_label")}: ${b.policyName} (${b.policyType})`);
                lines.push(`    ${tr("owner_label")}: ${b.ownerName}`);
                lines.push(`    ${tr("versioning_label")}: ${verStr}  |  ${tr("public_read_label")}: ${b.isPublic ? tr("yes") : tr("no")}`);
                lines.push(`    ${tr("encryption_label")}: ${b.isEncrypted ? tr("yes") : tr("no")}  |  ${tr("object_lock_label")}: ${b.isLocked ? `${b.lockMode}(${tr("retention_days").replace("{n}", String(b.retention))})` : tr("no")}`);
                lines.push(`    ${tr("created_at_label")}: ${b.createdAt}`);
                lines.push("");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Bucket ----
    server.tool("storefs_get_bucket", td("storefs_get_bucket"), {
        bucketId: z.string().optional().describe(td("storefs_get_bucket__bucketId")),
        ...bucketNameParam(),
    }, async ({ bucketId, bucketName }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const b = await AdminClient.getBucket(ref);
            const lines = [
                `${tr("bucket_detail_title")}:`,
                `  ID: ${b.id}`,
                `  Name: ${b.name}`,
                `  ${tr("policy_label")}: ${b.policyName} (${b.policyType})`,
                `  ${tr("owner_label")}: ${b.ownerName} (ID: ${b.ownerId})`,
                `  ${tr("versioning_label")}: ${b.versioning || tr("not_enabled")}`,
                `  ${tr("public_read_label")}: ${b.isPublic ? tr("yes") : tr("no")}`,
                `  ${tr("encryption_label")}: ${b.isEncrypted ? tr("yes") : tr("no")}`,
                `  ${tr("object_lock_label")}: ${b.isLocked ? `${b.lockMode}, ${tr("retention_days").replace("{n}", String(b.retention))}` : tr("not_enabled")}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Create Bucket ----
    server.tool("storefs_create_bucket", td("storefs_create_bucket"), {
        name: z.string().describe(td("storefs_create_bucket__name")),
        policyId: z.string().describe(td("storefs_create_bucket__policyId")),
        ownerId: z.string().optional().describe(td("storefs_create_bucket__ownerId")),
        versioning: z.enum(["Enabled", "Suspended"]).optional().describe(td("storefs_create_bucket__versioning")),
        isLocked: z.boolean().optional().describe(td("storefs_create_bucket__isLocked")),
        lockMode: z.enum(["GOVERNANCE", "COMPLIANCE"]).optional().describe(td("storefs_create_bucket__lockMode")),
        retention: z.number().optional().describe(td("storefs_create_bucket__retention")),
        isPublic: z.boolean().optional().describe(td("storefs_create_bucket__isPublic")),
        isEncrypted: z.boolean().optional().describe(td("storefs_create_bucket__isEncrypted")),
    }, async ({ name, policyId, ownerId, versioning, isLocked, lockMode, retention, isPublic, isEncrypted }) => {
        detectLang({ name });
        const lang = LANG;
        try {
            const b = await AdminClient.createBucket({ name, policyId, ownerId, versioning, isLocked, lockMode, retention, isPublic, isEncrypted });
            return { content: [{ type: "text", text: `${tr("bucket_created", lang)}: [${b.id}] ${b.name}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Update Bucket ----
    server.tool("storefs_update_bucket", td("storefs_update_bucket"), {
        bucketId: z.string().optional().describe(td("storefs_update_bucket__bucketId")),
        ...bucketNameParam(),
        name: z.string().optional().describe(td("storefs_update_bucket__name")),
        policyId: z.string().optional().describe(td("storefs_update_bucket__policyId")),
        versioning: z.enum(["Enabled", "Suspended"]).optional().describe(td("storefs_create_bucket__versioning")),
        isLocked: z.boolean().optional(),
        lockMode: z.enum(["GOVERNANCE", "COMPLIANCE"]).optional(),
        retention: z.number().optional(),
        isPublic: z.boolean().optional(),
        isEncrypted: z.boolean().optional(),
    }, async ({ bucketId, bucketName, ...rest }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const body = {};
            for (const [k, v] of Object.entries(rest))
                if (v !== undefined)
                    body[k] = v;
            await AdminClient.updateBucket(ref, body);
            return { content: [{ type: "text", text: `${tr("bucket_updated")}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Delete Bucket ----
    server.tool("storefs_delete_bucket", td("storefs_delete_bucket"), {
        bucketId: z.string().optional().describe(td("storefs_update_bucket__bucketId")),
        ...bucketNameParam(),
    }, async ({ bucketId, bucketName }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            await AdminClient.deleteBucket(ref);
            return { content: [{ type: "text", text: tr("bucket_deleted") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Generate Presigned URL ----
    server.tool("storefs_generate_presigned_url", td("storefs_generate_presigned_url"), {
        method: z.enum(["GET", "PUT", "POST"]).describe(td("storefs__httpMethod")),
        bucketId: z.string().optional().describe(td("storefs_generate_presigned_url__bucketId")),
        ...bucketNameParam(),
        objectName: z.string().describe(td("storefs_generate_presigned_url__objectName")),
        contentType: z.string().optional().describe("Content-Type"),
        host: z.string().optional().describe(td("storefs_generate_presigned_url__host")),
        versionId: z.string().optional().describe(td("storefs_generate_presigned_url__versionId")),
    }, async ({ method, bucketId, bucketName, objectName, contentType, host, versionId }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const result = await AdminClient.generatePresignedUrl({ method, bucketId: ref, objectName, contentType, host, versionId });
            return { content: [{ type: "text", text: [
                            `${tr("presigned_url_generated")}`,
                            `  URL: ${result.url}`,
                            `  Host: ${result.host}`,
                            `  ${tr("presigned_url_validity")}`,
                        ].join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Get Bucket ACL ----
    server.tool("storefs_get_bucket_acl", td("storefs_get_bucket_acl"), {
        bucketId: z.string().optional().describe(td("storefs_get_bucket_acl__bucketId")),
        ...bucketNameParam(),
    }, async ({ bucketId, bucketName }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const acl = await AdminClient.getBucketACL(ref);
            const lines = [
                `${tr("bucket_acl_title")}:`,
                `  ${tr("owner_label")}: ${acl.ownerName} (${acl.ownerId})`,
                "",
                `${tr("acl_grants")}:`,
            ];
            for (const g of acl.grants) {
                let grantee = "";
                switch (g.granteeType) {
                    case "canonical_user":
                        grantee = `${tr("user")}: ${g.granteeName || g.granteeId}`;
                        break;
                    case "all_users":
                        grantee = tr("acl_all_users");
                        break;
                    case "authenticated_users":
                        grantee = tr("acl_authenticated_users");
                        break;
                    default:
                        grantee = g.granteeType;
                }
                lines.push(`  - ${grantee} → ${g.permission}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Put Bucket ACL ----
    server.tool("storefs_put_bucket_acl", td("storefs_put_bucket_acl"), {
        bucketId: z.string().optional().describe(td("storefs_get_bucket_acl__bucketId")),
        ...bucketNameParam(),
        grants: z.array(z.object({
            granteeId: z.string().optional().describe(td("acl_grantee_id")),
            granteeUri: z.string().optional().describe(td("acl_grantee_uri")),
            granteeType: z.enum(["canonical_user", "all_users", "authenticated_users"]).describe(td("acl_grantee_type")),
            permission: z.enum(["FULL_CONTROL", "WRITE", "READ", "READ_ACP", "WRITE_ACP"]).describe(td("acl_permission")),
        }).refine(g => {
            if (g.granteeType === "canonical_user" && !g.granteeId)
                return false;
            if ((g.granteeType === "all_users" || g.granteeType === "authenticated_users") && !g.granteeUri)
                return false;
            return true;
        }, { message: "canonical_user requires granteeId; all_users/authenticated_users require granteeUri" })).describe(td("acl_grants")),
    }, async ({ bucketId, bucketName, grants }) => {
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            await AdminClient.putBucketACL(ref, grants);
            return { content: [{ type: "text", text: tr("bucket_acl_updated") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- List Dir Entries (NFS/SMB Gateway) ----
    server.tool("storefs_list_dir_entries", td("storefs_list_dir_entries"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
        prefix: z.string().optional().describe(td("storefs_list_dir_entries__prefix")),
    }, async ({ bucketName, prefix }) => {
        try {
            const data = await AdminClient.listDirEntries(bucketName, prefix);
            const lines = [`${tr("dir_entries_title")} (${bucketName}):`, ""];
            if (data.dirs.length > 0) {
                lines.push(`${tr("dir_entries_directories")}:`);
                for (const d of data.dirs) {
                    lines.push(`  📁 ${d.name}/  (${d.mtime})`);
                }
                lines.push("");
            }
            if (data.files.length > 0) {
                lines.push(`${tr("dir_entries_files")}:`);
                for (const f of data.files) {
                    lines.push(`  📄 ${f.name}  (${formatSize(f.size || 0)})  [${f.mtime}]`);
                }
                lines.push("");
            }
            if (data.dirs.length === 0 && data.files.length === 0) {
                lines.push(`  ${tr("dir_entries_empty")}`);
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Rebuild Dir Entries (NFS/SMB Gateway) ----
    server.tool("storefs_rebuild_dir_entries", td("storefs_rebuild_dir_entries"), {
        bucketName: z.string().describe(td("storefs__bucketName")),
    }, async ({ bucketName }) => {
        detectLang({ bucketName });
        const lang = LANG;
        try {
            const result = await AdminClient.rebuildDirEntries(bucketName);
            return { content: [{ type: "text", text: `${tr("dir_entries_rebuild_started", lang)}: ${result.bucket}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    // ---- Bucket Lifecycle ----
    server.tool("storefs_get_bucket_lifecycle", td("storefs_get_bucket_lifecycle"), {
        bucketId: z.string().optional().describe(td("storefs_get_bucket_lifecycle__bucketId")),
        ...bucketNameParam(),
    }, async ({ bucketId, bucketName }) => {
        detectLang({ bucketId });
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            const result = await AdminClient.getBucketLifecycle(ref);
            return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    server.tool("storefs_put_bucket_lifecycle", td("storefs_put_bucket_lifecycle"), {
        bucketId: z.string().optional().describe(td("storefs_put_bucket_lifecycle__bucketId")),
        ...bucketNameParam(),
        rules: z.array(z.any()).describe(td("storefs_put_bucket_lifecycle__rules")),
    }, async ({ bucketId, bucketName, rules }) => {
        detectLang({ bucketId, rules });
        const lang = LANG;
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            await AdminClient.putBucketLifecycle(ref, rules);
            return { content: [{ type: "text", text: tr("bucket_lifecycle_updated", lang) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
    server.tool("storefs_delete_bucket_lifecycle", td("storefs_delete_bucket_lifecycle"), {
        bucketId: z.string().optional().describe(td("storefs_delete_bucket_lifecycle__bucketId")),
        ...bucketNameParam(),
    }, async ({ bucketId, bucketName }) => {
        detectLang({ bucketId });
        const lang = LANG;
        try {
            const ref = bucketRef({ bucketId, bucketName });
            if (!ref)
                throw new Error("bucketId or bucketName is required");
            await AdminClient.deleteBucketLifecycle(ref);
            return { content: [{ type: "text", text: tr("bucket_lifecycle_deleted", lang) }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${e.message}` }] };
        }
    });
}
