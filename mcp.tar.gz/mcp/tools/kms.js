import { z } from "zod";
import * as AdminClient from "../api/admin-client.js";
import { LANG, tr, td } from "../i18n.js";
import { isAuthenticated } from "../auth/admin-auth.js";
export function registerKMSTools(server) {
    const needAuth = (handler) => async (...args) => {
        if (!isAuthenticated()) {
            return { content: [{ type: "text", text: tr("not_authenticated") }] };
        }
        return handler(...args);
    };
    // ---- Get KMS Config ----
    server.tool("storefs_get_kms_config", td("storefs_get_kms_config"), {}, needAuth(async () => {
        const lang = LANG;
        try {
            const config = await AdminClient.getKMSConfig();
            const lines = [
                `${tr("kms_config_title", lang)}:`,
                `  ${tr("kms_provider", lang)}: ${config.provider}`,
                `  ${tr("kms_endpoint", lang)}: ${config.endpoint}`,
                `  ${tr("kms_username", lang)}: ${config.username}`,
                `  ${tr("kms_password", lang)}: ${config.password}`,
                `  ${tr("kms_timeout", lang)}: ${config.timeout}s`,
                `  ${tr("kms_health_check_interval", lang)}: ${config.healthCheckInterval}s`,
                `  ${tr("kms_allow_degraded_reads", lang)}: ${config.allowDegradedReads ? tr("yes") : tr("no")}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Update KMS Config ----
    server.tool("storefs_update_kms_config", td("storefs_update_kms_config"), {
        endpoint: z.string().optional().describe(td("storefs_update_kms_config__endpoint")),
        provider: z.string().optional().describe(td("storefs_update_kms_config__provider")),
        providerConfig: z.record(z.string(), z.string()).optional().describe(td("storefs_update_kms_config__provider_config")),
        username: z.string().optional().describe(td("storefs_update_kms_config__username")),
        password: z.string().optional().describe(td("storefs_update_kms_config__password")),
        clientCert: z.string().optional().describe(td("storefs_update_kms_config__client_cert")),
        clientKey: z.string().optional().describe(td("storefs_update_kms_config__client_key")),
        caCert: z.string().optional().describe(td("storefs_update_kms_config__ca_cert")),
        timeout: z.number().optional().describe(td("storefs_update_kms_config__timeout")),
    }, needAuth(async (args) => {
        const lang = LANG;
        try {
            await AdminClient.updateKMSConfig(args);
            return { content: [{ type: "text", text: `✅ ${tr("kms_config_updated", lang)}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Test KMS Config ----
    server.tool("storefs_test_kms_config", td("storefs_test_kms_config"), {
        endpoint: z.string().describe(td("storefs_update_kms_config__endpoint")),
        provider: z.string().optional().describe(td("storefs_update_kms_config__provider")),
        providerConfig: z.record(z.string(), z.string()).optional().describe(td("storefs_update_kms_config__provider_config")),
        username: z.string().optional().describe(td("storefs_update_kms_config__username")),
        password: z.string().optional().describe(td("storefs_update_kms_config__password")),
        clientCert: z.string().optional().describe(td("storefs_update_kms_config__client_cert")),
        clientKey: z.string().optional().describe(td("storefs_update_kms_config__client_key")),
        caCert: z.string().optional().describe(td("storefs_update_kms_config__ca_cert")),
        timeout: z.number().optional().describe(td("storefs_update_kms_config__timeout")),
    }, needAuth(async (args) => {
        const lang = LANG;
        try {
            const result = await AdminClient.testKMSConfig(args);
            if (result.success) {
                return { content: [{ type: "text", text: `✅ ${tr("kms_test_success", lang)}: ${result.message}` }] };
            }
            return { content: [{ type: "text", text: `❌ ${tr("kms_test_failed", lang)}: ${result.message}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("kms_test_failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Check KMS Health ----
    server.tool("storefs_check_kms_health", td("storefs_check_kms_health"), {}, needAuth(async () => {
        const lang = LANG;
        try {
            const health = await AdminClient.checkKMSHealth();
            const statusText = health.status === "online" ? tr("kms_online", lang) : tr("kms_offline", lang);
            const lines = [
                `${tr("kms_config_title", lang)}: ${statusText}`,
                `${tr("kms_endpoint", lang)}: ${health.endpoint}`,
                `${tr("kms_provider", lang)}: ${health.provider}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("kms_offline", lang)}: ${e.message}` }] };
        }
    }));
    // ---- List KMS Configs ----
    server.tool("storefs_list_kms_configs", td("storefs_list_kms_configs"), {}, needAuth(async () => {
        const lang = LANG;
        try {
            const result = await AdminClient.listKMSConfigs();
            if (!result.configs || result.configs.length === 0) {
                return { content: [{ type: "text", text: tr("kms_no_configs", lang) }] };
            }
            const lines = [tr("kms_configs_title", lang)];
            for (const cfg of result.configs) {
                lines.push(`  ${cfg.name || cfg.id} (${cfg.id})`);
                lines.push(`    ${tr("kms_provider", lang)}: ${cfg.provider}`);
                lines.push(`    ${tr("kms_endpoint", lang)}: ${cfg.endpoint}`);
                lines.push("---");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Create KMS Config ----
    server.tool("storefs_create_kms_config", td("storefs_create_kms_config"), {
        name: z.string().describe(td("storefs_create_kms_config__name")),
        description: z.string().optional().describe(td("storefs_create_kms_config__description")),
        endpoint: z.string().describe(td("storefs_create_kms_config__endpoint")),
        provider: z.string().optional().describe(td("storefs_create_kms_config__provider")),
        username: z.string().optional().describe(td("storefs_create_kms_config__username")),
        password: z.string().optional().describe(td("storefs_create_kms_config__password")),
        clientCert: z.string().optional().describe(td("storefs_create_kms_config__client_cert")),
        clientKey: z.string().optional().describe(td("storefs_create_kms_config__client_key")),
        caCert: z.string().optional().describe(td("storefs_create_kms_config__ca_cert")),
        timeout: z.number().optional().describe(td("storefs_create_kms_config__timeout")),
        allowDegradedReads: z.boolean().optional().describe(td("storefs_create_kms_config__allow_degraded_reads")),
    }, needAuth(async (args) => {
        const lang = LANG;
        try {
            const result = await AdminClient.createKMSConfig(args);
            return { content: [{ type: "text", text: `✅ ${tr("kms_config_created", lang)} (${result.id})` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Get KMS Config by ID ----
    server.tool("storefs_get_kms_config_by_id", td("storefs_get_kms_config_by_id"), { configId: z.number().describe(td("storefs_get_kms_config_by_id__config_id")) }, needAuth(async ({ configId }) => {
        const lang = LANG;
        try {
            const config = await AdminClient.getKMSConfigByID(configId);
            const lines = [
                `${tr("kms_config_title", lang)}: ${config.name || config.id} (${config.id})`,
                `  ${tr("kms_provider", lang)}: ${config.provider}`,
                `  ${tr("kms_endpoint", lang)}: ${config.endpoint}`,
                `  ${tr("kms_username", lang)}: ${config.username}`,
                `  ${tr("kms_password", lang)}: ${config.password}`,
                `  ${tr("kms_timeout", lang)}: ${config.timeout}s`,
                `  ${tr("kms_health_check_interval", lang)}: ${config.healthCheckInterval}s`,
                `  ${tr("kms_allow_degraded_reads", lang)}: ${config.allowDegradedReads ? tr("yes") : tr("no")}`,
            ];
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Delete KMS Config ----
    server.tool("storefs_delete_kms_config", td("storefs_delete_kms_config"), { configId: z.number().describe(td("storefs_delete_kms_config__config_id")) }, needAuth(async ({ configId }) => {
        const lang = LANG;
        try {
            await AdminClient.deleteKMSConfig(configId);
            return { content: [{ type: "text", text: `✅ ${tr("kms_config_deleted", lang)}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- List KMS Keys ----
    server.tool("storefs_list_kms_keys", td("storefs_list_kms_keys"), {
        page: z.number().optional().describe(td("storefs_list_kms_keys__page")),
        pageSize: z.number().optional().describe(td("storefs_list_kms_keys__page_size")),
        groupId: z.union([z.string(), z.number()]).optional().describe(td("storefs_list_kms_keys__group_id")),
        showRetired: z.boolean().optional().describe(td("storefs_list_kms_keys__show_retired")),
    }, needAuth(async ({ page, pageSize, groupId, showRetired }) => {
        const lang = LANG;
        try {
            const result = await AdminClient.listKMSKeys({ page, pageSize, groupId, showRetired });
            if (!result.keys || result.keys.length === 0) {
                return { content: [{ type: "text", text: tr("kms_no_keys", lang) }] };
            }
            const lines = [tr("kms_keys_title", lang)];
            for (const key of result.keys) {
                lines.push(`  ${tr("kms_key_id", lang)}: ${key.keyId}`);
                if (key.alias)
                    lines.push(`  ${tr("kms_alias", lang)}: ${key.alias}`);
                lines.push(`  ${tr("kms_status", lang)}: ${key.status === "retired" ? tr("kms_retired", lang) : key.status}`);
                if (key.retiredAt)
                    lines.push(`  ${tr("kms_retired_at", lang)}: ${key.retiredAt}`);
                const groupLabel = key.groupName ? `${key.groupName} (${key.groupId || "0"})` : (key.groupId || "0");
                lines.push(`  ${tr("kms_group_id", lang)}: ${groupLabel}`);
                if (key.provider)
                    lines.push(`  ${tr("kms_provider", lang)}: ${key.provider}`);
                lines.push("---");
            }
            return { content: [{ type: "text", text: lines.join("\n") }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Create KMS Key ----
    server.tool("storefs_create_kms_key", td("storefs_create_kms_key"), {
        alias: z.string().describe(td("storefs_create_kms_key__alias")),
        description: z.string().optional().describe(td("storefs_create_kms_key__description")),
        groupId: z.union([z.string(), z.number()]).optional().describe(td("storefs_create_kms_key__group_id")),
        provider: z.string().optional().describe(td("storefs_create_kms_key__provider")),
        kmsConfigId: z.union([z.string(), z.number()]).optional().describe(td("storefs_create_kms_key__kms_config_id")),
    }, needAuth(async ({ alias, description, groupId, provider, kmsConfigId }) => {
        const lang = LANG;
        try {
            // Convert to string to avoid JS precision loss for snowflake IDs
            const payload = { alias, description, provider };
            if (groupId !== undefined)
                payload.groupId = String(groupId);
            if (kmsConfigId !== undefined)
                payload.kmsConfigId = String(kmsConfigId);
            const key = await AdminClient.createKMSKey(payload);
            return {
                content: [{ type: "text", text: `✅ ${tr("success", lang)}\n${tr("kms_key_id", lang)}: ${key.keyId}\n${tr("kms_alias", lang)}: ${key.alias}` }],
            };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Rotate KMS Key ----
    server.tool("storefs_rotate_kms_key", td("storefs_rotate_kms_key"), { keyId: z.string().describe(td("storefs_rotate_kms_key__key_id")) }, needAuth(async ({ keyId }) => {
        const lang = LANG;
        try {
            const key = await AdminClient.rotateKMSKey(keyId);
            return { content: [{ type: "text", text: `✅ ${tr("success", lang)}\n${tr("kms_key_id", lang)}: ${key.newKey.keyId}\n${tr("kms_alias", lang)}: ${key.newKey.alias}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
    // ---- Delete KMS Key ----
    server.tool("storefs_delete_kms_key", td("storefs_delete_kms_key"), { keyId: z.string().describe(td("storefs_delete_kms_key__key_id")) }, needAuth(async ({ keyId }) => {
        const lang = LANG;
        try {
            await AdminClient.deleteKMSKey(keyId);
            return { content: [{ type: "text", text: `✅ ${tr("success", lang)}` }] };
        }
        catch (e) {
            return { content: [{ type: "text", text: `❌ ${tr("failed", lang)}: ${e.message}` }] };
        }
    }));
}
