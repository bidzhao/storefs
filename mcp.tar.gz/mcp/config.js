function envStr(key, fallback) {
    return process.env[key] ?? fallback;
}
function envInt(key, fallback) {
    const v = process.env[key];
    if (!v)
        return fallback;
    const n = parseInt(v, 10);
    return isNaN(n) ? fallback : n;
}
let _cfg = null;
export function loadConfig() {
    if (_cfg)
        return _cfg;
    _cfg = {
        adminUrl: envStr("STOREFS_ADMIN_URL", "http://127.0.0.1:7946"),
        s3Url: envStr("STOREFS_S3_URL", "http://127.0.0.1:8901"),
        ssePort: envInt("STOREFS_PORT", 3100),
        pat: process.env.STOREFS_PAT ?? undefined,
    };
    return _cfg;
}
