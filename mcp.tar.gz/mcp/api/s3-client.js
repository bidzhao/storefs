/**
 * S3 REST API client.
 * Port 8901 — standard S3 API with SigV4 authentication.
 */
import { XMLParser } from "fast-xml-parser";
import { loadConfig } from "../config.js";
import { signS3Request } from "../auth/s3-auth.js";
const xmlParser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: "@_",
});
function s3BaseUrl() {
    return loadConfig().s3Url.replace(/\/+$/, "");
}
/**
 * Make a signed S3 request and parse the response.
 */
async function signedFetch(creds, method, path, body, extraHeaders) {
    const { url, headers } = await signS3Request(s3BaseUrl(), { method, path, headers: extraHeaders, body }, creds);
    return fetch(url, {
        method,
        headers,
        body: body ?? undefined,
    });
}
/** List all buckets for the authenticated user. */
export async function listBuckets(creds) {
    const res = await signedFetch(creds, "GET", "/");
    if (!res.ok) {
        throw new Error(`S3 ListBuckets failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
    const xml = await res.text();
    const parsed = xmlParser.parse(xml);
    const buckets = parsed?.ListAllMyBucketsResult?.Buckets?.Bucket;
    if (!buckets)
        return [];
    return Array.isArray(buckets) ? buckets : [buckets];
}
/** Head object — returns metadata. */
export async function headObject(creds, bucketName, objectName, versionId) {
    let path = `/${bucketName}/${encodeURIComponent(objectName)}`;
    if (versionId)
        path += `?versionId=${versionId}`;
    const res = await signedFetch(creds, "HEAD", path);
    if (!res.ok) {
        throw new Error(`S3 HeadObject failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
    const headers = {};
    res.headers.forEach((v, k) => {
        headers[k] = v;
    });
    return headers;
}
/** Get object content as text. */
export async function getObject(creds, bucketName, objectName, versionId, maxSize) {
    let path = `/${bucketName}/${encodeURIComponent(objectName)}`;
    if (versionId)
        path += `?versionId=${versionId}`;
    const res = await signedFetch(creds, "GET", path);
    if (!res.ok) {
        throw new Error(`S3 GetObject failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
    const contentLength = parseInt(res.headers.get("content-length") ?? "0");
    const limit = maxSize ?? 1_048_576;
    if (contentLength > limit) {
        // Don't read the body — too large
        const headers = {};
        res.headers.forEach((v, k) => { headers[k] = v; });
        return {
            contentType: res.headers.get("content-type") ?? "application/octet-stream",
            contentLength,
            etag: res.headers.get("etag") ?? "",
            body: "",
            headers,
        };
    }
    const headers = {};
    res.headers.forEach((v, k) => {
        headers[k] = v;
    });
    // Read as text — for non-text content the tool handler will detect and skip
    return {
        contentType: res.headers.get("content-type") ?? "application/octet-stream",
        contentLength,
        etag: res.headers.get("etag") ?? "",
        body: await res.text(),
        headers,
    };
}
/** Get object content as raw ArrayBuffer (for file downloads). */
export async function getObjectAsBuffer(creds, bucketName, objectName, versionId) {
    let path = `/${bucketName}/${encodeURIComponent(objectName)}`;
    if (versionId)
        path += `?versionId=${versionId}`;
    const res = await signedFetch(creds, "GET", path);
    if (!res.ok) {
        throw new Error(`S3 GetObject failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
    const headers = {};
    res.headers.forEach((v, k) => { headers[k] = v; });
    return {
        contentType: res.headers.get("content-type") ?? "application/octet-stream",
        contentLength: parseInt(res.headers.get("content-length") ?? "0"),
        etag: res.headers.get("etag") ?? "",
        buffer: await res.arrayBuffer(),
        headers,
    };
}
/** Put an object. */
export async function putObject(creds, bucketName, objectName, content, contentType, tags) {
    const path = `/${bucketName}/${encodeURIComponent(objectName)}`;
    const extraHeaders = {};
    if (contentType)
        extraHeaders["content-type"] = contentType;
    if (tags)
        extraHeaders["x-amz-tagging"] = tags;
    const res = await signedFetch(creds, "PUT", path, content, extraHeaders);
    if (!res.ok) {
        throw new Error(`S3 PutObject failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
    return {
        etag: res.headers.get("etag") ?? "",
        versionId: res.headers.get("x-amz-version-id"),
    };
}
/** Delete an object. */
export async function deleteObject(creds, bucketName, objectName, versionId) {
    let path = `/${bucketName}/${encodeURIComponent(objectName)}`;
    if (versionId)
        path += `?versionId=${versionId}`;
    const res = await signedFetch(creds, "DELETE", path);
    if (!res.ok && res.status !== 204) {
        throw new Error(`S3 DeleteObject failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
}
/** Copy object between buckets (or within same bucket). */
export async function copyObject(creds, sourceBucket, sourceObject, targetBucket, targetObject, sourceVersionId, extraHeaders) {
    let copySource = `/${sourceBucket}/${encodeURIComponent(sourceObject)}`;
    if (sourceVersionId)
        copySource += `?versionId=${sourceVersionId}`;
    const path = `/${targetBucket}/${encodeURIComponent(targetObject)}`;
    const res = await signedFetch(creds, "PUT", path, undefined, {
        "x-amz-copy-source": copySource,
        ...(extraHeaders || {}),
    });
    if (!res.ok) {
        throw new Error(`S3 CopyObject failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
    const xml = await res.text();
    const parsed = xmlParser.parse(xml);
    const result = parsed?.CopyObjectResult;
    return {
        lastModified: result?.LastModified ?? "",
        etag: result?.ETag ?? "",
    };
}
/** Get object tagging. */
export async function getObjectTagging(creds, bucketName, objectName, versionId) {
    let path = `/${bucketName}/${encodeURIComponent(objectName)}?tagging`;
    if (versionId)
        path += `&versionId=${versionId}`;
    const res = await signedFetch(creds, "GET", path);
    if (!res.ok) {
        throw new Error(`S3 GetObjectTagging failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
    const xml = await res.text();
    const parsed = xmlParser.parse(xml);
    const tags = parsed?.Tagging?.TagSet?.Tag;
    if (!tags)
        return [];
    return Array.isArray(tags) ? tags : [tags];
}
/** Put object tagging. */
export async function putObjectTagging(creds, bucketName, objectName, tags, versionId) {
    let path = `/${bucketName}/${encodeURIComponent(objectName)}?tagging`;
    if (versionId)
        path += `&versionId=${versionId}`;
    const tagXml = `<?xml version="1.0" encoding="UTF-8"?>
<Tagging xmlns="http://s3.amazonaws.com/doc/2006-03-01/">
  <TagSet>
    ${tags.map(t => `<Tag><Key>${escapeXml(t.key)}</Key><Value>${escapeXml(t.value)}</Value></Tag>`).join('\n    ')}
  </TagSet>
</Tagging>`;
    const res = await signedFetch(creds, "PUT", path, tagXml, {
        "content-type": "application/xml",
    });
    if (!res.ok && res.status !== 200) {
        throw new Error(`S3 PutObjectTagging failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
}
/** Delete object tagging. */
export async function deleteObjectTagging(creds, bucketName, objectName, versionId) {
    let path = `/${bucketName}/${encodeURIComponent(objectName)}?tagging`;
    if (versionId)
        path += `&versionId=${versionId}`;
    const res = await signedFetch(creds, "DELETE", path);
    if (!res.ok && res.status !== 204) {
        throw new Error(`S3 DeleteObjectTagging failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
}
/** Get bucket tagging. */
export async function getBucketTagging(creds, bucketName) {
    const path = `/${bucketName}?tagging`;
    const res = await signedFetch(creds, "GET", path);
    if (!res.ok) {
        throw new Error(`S3 GetBucketTagging failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
    const xml = await res.text();
    const parsed = xmlParser.parse(xml);
    const tags = parsed?.Tagging?.TagSet?.Tag;
    if (!tags)
        return [];
    return Array.isArray(tags) ? tags : [tags];
}
/** Put bucket tagging. */
export async function putBucketTagging(creds, bucketName, tags) {
    const path = `/${bucketName}?tagging`;
    const tagXml = `<?xml version="1.0" encoding="UTF-8"?>
<Tagging xmlns="http://s3.amazonaws.com/doc/2006-03-01/">
  <TagSet>
    ${tags.map(t => `<Tag><Key>${escapeXml(t.key)}</Key><Value>${escapeXml(t.value)}</Value></Tag>`).join('\n    ')}
  </TagSet>
</Tagging>`;
    const res = await signedFetch(creds, "PUT", path, tagXml, {
        "content-type": "application/xml",
    });
    if (!res.ok && res.status !== 200) {
        throw new Error(`S3 PutBucketTagging failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
}
/** Delete bucket tagging. */
export async function deleteBucketTagging(creds, bucketName) {
    const path = `/${bucketName}?tagging`;
    const res = await signedFetch(creds, "DELETE", path);
    if (!res.ok && res.status !== 204) {
        throw new Error(`S3 DeleteBucketTagging failed (${res.status}): ${await res.text().catch(() => "unknown")}`);
    }
}
function escapeXml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
