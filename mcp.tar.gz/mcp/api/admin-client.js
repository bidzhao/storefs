/**
 * Admin API HTTP client.
 * All Admin REST API calls go through this module.
 * Port 7946 — gossip+HTTP multiplexed port.
 */
import { loadConfig } from "../config.js";
import { getAuthHeader, updateToken } from "../auth/admin-auth.js";
import { tr } from "../i18n.js";
// ---- Raw HTTP helpers ----
let _baseUrl = null;
function baseUrl() {
    if (!_baseUrl)
        _baseUrl = loadConfig().adminUrl.replace(/\/+$/, "");
    return _baseUrl;
}
function url(path) {
    // Ensure path starts with /
    return `${baseUrl()}/api${path.startsWith("/") ? path : "/" + path}`;
}
class AdminApiError extends Error {
    status;
    constructor(status, message) {
        super(message);
        this.status = status;
        this.name = "AdminApiError";
    }
}
function safeParseInt(v, label) {
    if (v === undefined || v === null)
        return undefined;
    const n = parseInt(v, 10);
    if (isNaN(n))
        throw new Error(`Invalid ${label}: "${v}"`);
    return n;
}
/** Same as callRaw but without Authorization header — for endpoints that don't require auth */
async function callRawNoAuth(method, path, body, params) {
    const u = new URL(url(path));
    if (params) {
        for (const [k, v] of Object.entries(params)) {
            if (v !== undefined && v !== "") {
                u.searchParams.set(k, String(v));
            }
        }
    }
    const res = await fetch(u.toString(), {
        method,
        headers: {
            "Content-Type": body ? "application/json" : "application/json",
        },
        body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) {
        const text = await res.text().catch(() => "unknown error");
        throw new AdminApiError(res.status, `Admin API error (${res.status}): ${text}`);
    }
    return res;
}
async function callRaw(method, path, body, params) {
    const u = new URL(url(path));
    if (params) {
        for (const [k, v] of Object.entries(params)) {
            if (v !== undefined && v !== "") {
                u.searchParams.set(k, String(v));
            }
        }
    }
    const res = await fetch(u.toString(), {
        method,
        headers: {
            Authorization: getAuthHeader(),
            "Content-Type": body ? "application/json" : "application/json",
        },
        body: body ? JSON.stringify(body) : undefined,
    });
    // Sliding renewal: check for new token in response header
    const newToken = res.headers.get("x-new-access-token");
    if (newToken) {
        updateToken(newToken);
    }
    if (res.status === 401) {
        throw new AdminApiError(401, tr("auth_expired"));
    }
    if (!res.ok) {
        const text = await res.text().catch(() => "unknown error");
        throw new AdminApiError(res.status, `Admin API error (${res.status}): ${text}`);
    }
    return res;
}
async function call(method, path, body, params) {
    const res = await callRaw(method, path, body, params);
    const text = await res.text();
    // Snowflake IDs 是 16-19 位大整数，JavaScript Number 无法精确表示。
    // 在 JSON.parse 之前把大整数转成字符串，避免精度丢失。
    const safe = text.replace(/:\s*(\d{16,})\s*([,}\]])/g, ': "$1"$2');
    return JSON.parse(safe);
}
// ---- Auth ----
export async function login(username, password) {
    const res = await fetch(url("/auth/login"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
    });
    if (!res.ok) {
        const text = await res.text().catch(() => "unknown error");
        throw new AdminApiError(res.status, `Login failed: ${text}`);
    }
    return res.json();
}
/** Verify MFA code during login and receive full JWT */
export async function verifyMFALogin(tempToken, code) {
    const res = await fetch(url("/auth/mfa/verify-login"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tempToken, code }),
    });
    if (!res.ok) {
        const text = await res.text().catch(() => "unknown error");
        throw new AdminApiError(res.status, `MFA verification failed: ${text}`);
    }
    const data = await res.json();
    if (!data.success) {
        throw new Error(data.error || "MFA verification failed");
    }
    return data;
}
/** Login with a Personal Access Token (bypasses MFA) */
export async function loginWithPAT(pat) {
    const res = await fetch(url("/auth/user"), {
        method: "GET",
        headers: {
            Authorization: `Bearer ${pat}`,
            "Content-Type": "application/json",
        },
    });
    if (!res.ok) {
        const text = await res.text().catch(() => "unknown error");
        throw new AdminApiError(res.status, `PAT login failed: ${text}`);
    }
    const data = await res.json();
    // Construct a LoginResponse-like object from the /auth/user result
    const user = data.user || {};
    return {
        success: true,
        id: user.id,
        name: user.name,
        role: user.role,
        groupId: user.groupId,
        groupName: user.groupName,
        mustChangePassword: user.mustChangePassword,
        token: pat, // store PAT as the token for the auth header
        message: "login successful",
    };
}
export async function logout() {
    await callRaw("POST", "/auth/logout");
}
// ---- Users ----
export async function listUsers(params) {
    return call("GET", "/users", undefined, params);
}
export async function getUser(userId) {
    return call("GET", `/users/${userId}`);
}
export async function createUser(body) {
    return call("POST", "/users", body);
}
export async function updateUser(userId, body) {
    return call("PUT", `/users/${userId}`, body);
}
export async function deleteUser(userId) {
    await callRaw("DELETE", `/users/${userId}`);
}
export async function getAccessKeys(userId) {
    return call("GET", `/users/${userId}/access-keys`);
}
export async function rotateAccessKeys(userId) {
    return call("POST", `/users/${userId}/access-keys`);
}
export async function resetPassword(userId, password, mustChangePassword) {
    await callRaw("PUT", `/users/${userId}/reset-password`, {
        password,
        mustChangePassword,
    });
}
export async function disableUserMFA(userId) {
    await callRaw("PUT", `/users/${userId}/disable-mfa`);
}
// ---- Groups ----
export async function listGroups(params) {
    return call("GET", "/groups", undefined, params);
}
export async function getGroup(groupId) {
    return call("GET", `/groups/${groupId}`);
}
export async function createGroup(name, defaultPolicyId) {
    return call("POST", "/groups", { name, defaultPolicyId: safeParseInt(defaultPolicyId, "defaultPolicyId") });
}
export async function updateGroup(groupId, body) {
    // Convert string IDs to numbers for the server API
    const apiBody = {};
    if (body.name !== undefined)
        apiBody.name = body.name;
    if (body.defaultPolicyId !== undefined)
        apiBody.defaultPolicyId = safeParseInt(body.defaultPolicyId, "defaultPolicyId");
    return call("PUT", `/groups/${groupId}`, apiBody);
}
export async function deleteGroup(groupId) {
    await callRaw("DELETE", `/groups/${groupId}`);
}
// ---- Policies ----
export async function listPolicies(params) {
    return call("GET", "/policies", undefined, params);
}
export async function getPolicy(policyId) {
    return call("GET", `/policies/${policyId}`);
}
/** Normalize a raw policy struct from the backend (capital-field JSON keys) to PolicyResponse. */
function normalizePolicyResponse(raw) {
    return {
        id: String(raw.ID ?? raw.id ?? ""),
        name: raw.Name ?? raw.name ?? "",
        type: raw.Type ?? raw.type ?? "",
        replicas: raw.Replicas ?? raw.replicas ?? 0,
        dataShards: raw.DataShards ?? raw.dataShards ?? 0,
        parityShards: raw.ParityShards ?? raw.parityShards ?? 0,
        createdAt: raw.CreatedAt ?? raw.createdAt ?? "",
    };
}
export async function createPolicy(body) {
    // 后端 POST /policies 返回 raw store struct（大写字段，如 {"ID":123,"Name":...}），
    // 这里映射为 PolicyResponse 的小写 camelCase 格式。
    const raw = await call("POST", "/policies", body);
    return normalizePolicyResponse(raw);
}
export async function updatePolicy(policyId, body) {
    // 后端 PUT /policies/:id 返回 raw store struct（大写字段），映射为小写 camelCase
    const raw = await call("PUT", `/policies/${policyId}`, body);
    return normalizePolicyResponse(raw);
}
export async function deletePolicy(policyId) {
    await callRaw("DELETE", `/policies/${policyId}`);
}
// ---- Buckets ----
export async function listBuckets(params) {
    return call("GET", "/buckets", undefined, params);
}
export async function getBucket(bucketId) {
    return call("GET", `/buckets/${bucketId}`);
}
export async function createBucket(body) {
    return call("POST", "/buckets", {
        ...body,
        // Go 后端使用 json:"policyId,string" 结构体标签，期望 JSON 字符串值
        policyId: String(body.policyId),
        ownerId: body.ownerId !== undefined ? String(body.ownerId) : undefined,
    });
}
export async function updateBucket(bucketId, body) {
    return call("PUT", `/buckets/${bucketId}`, body);
}
export async function deleteBucket(bucketId) {
    await callRaw("DELETE", `/buckets/${bucketId}`);
}
// ---- Bucket ACL ----
export async function getBucketACL(bucketId) {
    return call("GET", `/buckets/${bucketId}/acl`);
}
export async function putBucketACL(bucketId, grants) {
    await callRaw("PUT", `/buckets/${bucketId}/acl`, { grants });
}
// ---- Bucket Lifecycle ----
export async function getBucketLifecycle(bucketId) {
    return callRaw("GET", `/buckets/${bucketId}/lifecycle`);
}
export async function putBucketLifecycle(bucketId, rules) {
    await callRaw("PUT", `/buckets/${bucketId}/lifecycle`, { rules });
}
export async function deleteBucketLifecycle(bucketId) {
    await callRaw("DELETE", `/buckets/${bucketId}/lifecycle`);
}
export async function generatePresignedUrl(body) {
    return call("POST", `/buckets/${body.bucketId}/s3-presigned-url`, {
        ...body,
        // Go 后端使用 json:"bucketId,string" 结构体标签，期望 JSON 字符串值
        bucketId: String(body.bucketId),
    });
}
// ---- Lifecycle Scanner Config ----
export async function getLifecycleConfig() {
    return call("GET", "/lifecycle/config");
}
export async function putLifecycleConfig(body) {
    await callRaw("PUT", "/lifecycle/config", body);
}
// ---- Objects ----
export async function listObjects(bucketId, params) {
    return call("GET", `/buckets/${bucketId}/objects`, undefined, params);
}
export async function getObjectInfo(bucketId, objectName) {
    const res = await callRaw("GET", `/object/info`, undefined, { bucket: bucketId, object: objectName });
    return res.json();
}
export async function getObjectVersions(bucketId, objectName, params) {
    const u = `/buckets/${bucketId}/objects/${encodeURIComponent(objectName)}/versions`;
    return call("GET", u, undefined, params);
}
export async function deleteObject(bucketId, objectName, version) {
    // The Go Admin API reads version from a custom HTTP header "version"
    const u = url(`/buckets/${bucketId}/objects/${encodeURIComponent(objectName)}`);
    const res = await fetch(u.toString(), {
        method: "DELETE",
        headers: {
            Authorization: getAuthHeader(),
            ...(version ? { version } : {}),
        },
    });
    if (res.status === 401) {
        throw new AdminApiError(401, tr("auth_expired"));
    }
    if (!res.ok) {
        const text = await res.text().catch(() => "unknown error");
        throw new AdminApiError(res.status, `Admin API error (${res.status}): ${text}`);
    }
}
// ---- Multipart ----
export async function listMultipartUploads(bucketId, params) {
    return call("GET", `/buckets/${bucketId}/multipart-uploads`, undefined, params);
}
export async function getMultipartUpload(uploadId, bucketId, objectName) {
    return call("GET", `/multipart-uploads/${uploadId}`, undefined, {
        bucketId,
        objectName,
    });
}
export async function completeMultipartUpload(uploadId, bucketId, objectName, partNumbers) {
    await callRaw("POST", `/multipart-uploads/${uploadId}/complete`, {
        partNumbers: partNumbers ?? [],
        bucketId,
        objectName,
    });
}
export async function abortMultipartUpload(uploadId, bucketId, objectName) {
    await callRaw("DELETE", `/multipart-uploads/${uploadId}`, undefined, {
        bucketId,
        objectName,
    });
}
export async function getPartFragmentInfo(uploadId, partNumber, bucketId, objectName) {
    return call("GET", `/parts/${uploadId}/${partNumber}/fragments`, undefined, { bucketId, objectName });
}
// ---- Node / Cluster ----
export async function getNodeStatus() {
    return call("GET", "/node/mystatus");
}
export async function getAllNodeStatus() {
    return call("GET", "/node/status");
}
export async function getMembers() {
    const cfg = loadConfig();
    const res = await fetch(`${cfg.adminUrl.replace(/\/+$/, "")}/members`, {
        headers: { Authorization: getAuthHeader() },
    });
    if (!res.ok) {
        const text = await res.text().catch(() => "unknown error");
        throw new AdminApiError(res.status, `Failed to get members: ${text}`);
    }
    return res.json();
}
// ---- Raft ----
export async function getRaftLeader() {
    const res = await callRawNoAuth("GET", "/raft/leader");
    const text = await res.text();
    const safe = text.replace(/:\s*(\d{16,})\s*([,}\]])/g, ': "$1"$2');
    return JSON.parse(safe);
}
// ---- Metrics ----
export async function getMetrics() {
    const cfg = loadConfig();
    const res = await fetch(`${cfg.adminUrl.replace(/\/+$/, "")}/metrics`);
    if (!res.ok)
        throw new AdminApiError(res.status, "Failed to fetch metrics");
    return res.text();
}
// ---- Node Status ----
export async function listNodeStatus() {
    return call("GET", "/node-status");
}
export async function updateNodeStatus(nodeName, status) {
    return call("PUT", `/node-status/${nodeName}`, { status });
}
// ---- Tasks ----
export async function listTasks(params) {
    return call("GET", "/tasks", undefined, params);
}
export async function getTask(taskId) {
    return call("GET", `/tasks/${taskId}`);
}
export async function createTask(type, params) {
    // Send params as raw JSON object, not double-encoded string
    return call("POST", "/tasks", { type, params });
}
export async function cancelTask(taskId) {
    return call("POST", `/tasks/${taskId}/cancel`);
}
export async function deleteTask(taskId) {
    await callRaw("DELETE", `/tasks/${taskId}`);
    return { success: true };
}
export async function listTaskTypes() {
    return call("GET", "/tasks/types");
}
export async function cleanupTasks(days) {
    return call("POST", "/tasks/cleanup", { days });
}
// ===== Bucket Notification =====
export async function listBucketNotifications(bucketId) {
    return call("GET", `/buckets/${bucketId}/notifications`);
}
export async function getNotification(notificationId) {
    return call("GET", `/notifications/${notificationId}`);
}
export async function createNotification(bucketId, body) {
    return call("POST", `/buckets/${bucketId}/notifications`, body);
}
export async function updateNotification(notificationId, body) {
    return call("PUT", `/notifications/${notificationId}`, body);
}
export async function deleteNotification(notificationId) {
    await callRaw("DELETE", `/notifications/${notificationId}`);
}
export async function testWebhook(url, secret, format) {
    return call("POST", "/notifications/test", { url, secret, format });
}
// ===== Dir Entries (NFS/SMB Gateway) =====
export async function listDirEntries(bucketName, prefix) {
    return call("GET", `/buckets/${encodeURIComponent(bucketName)}/entries`, undefined, { prefix });
}
export async function rebuildDirEntries(bucketName) {
    return call("POST", "/buckets/entries/rebuild", undefined, { bucket: bucketName });
}
// ===== Gateway Status =====
export async function getGatewayStatus() {
    return call("GET", "/gateway/status");
}
export async function listAuditLogs(params) {
    return call("GET", "/audit-logs", undefined, params);
}
export async function getAuditConfig() {
    return call("GET", "/audit/config");
}
// ===== KMS Config =====
export async function getKMSConfig() {
    return call("GET", "/kms/config");
}
export async function updateKMSConfig(data) {
    return call("PUT", "/kms/config", data);
}
export async function testKMSConfig(data) {
    return call("POST", "/kms/config/test", data);
}
export async function checkKMSHealth() {
    return call("GET", "/kms/config/health");
}
// KMS Configs (multi-config)
export async function listKMSConfigs() {
    return call("GET", "/kms/configs");
}
export async function createKMSConfig(data) {
    return call("POST", "/kms/configs", data);
}
export async function getKMSConfigByID(id) {
    return call("GET", `/kms/configs/${id}`);
}
export async function updateKMSConfigByID(id, data) {
    return call("PUT", `/kms/configs/${id}`, data);
}
export async function deleteKMSConfig(id) {
    return call("DELETE", `/kms/configs/${id}`);
}
export async function testKMSConfigByID(id, data) {
    return call("POST", `/kms/configs/${id}/test`, data);
}
export async function checkKMSHealthByID(id) {
    return call("GET", `/kms/configs/${id}/health`);
}
// ===== KMS Keys =====
export async function listKMSKeys(params) {
    const queryParams = {};
    if (params) {
        if (params.page !== undefined)
            queryParams.page = params.page;
        if (params.pageSize !== undefined)
            queryParams.pageSize = params.pageSize;
        if (params.groupId !== undefined)
            queryParams.groupId = params.groupId;
        if (params.showRetired !== undefined)
            queryParams.showRetired = params.showRetired ? "true" : "false";
    }
    return call("GET", "/kms/keys", undefined, queryParams);
}
export async function getKMSKey(id) {
    return call("GET", `/kms/keys/${id}`);
}
export async function createKMSKey(data) {
    return call("POST", "/kms/keys", data);
}
export async function updateKMSKey(id, data) {
    return call("PUT", `/kms/keys/${id}`, data);
}
export async function deleteKMSKey(id) {
    return call("DELETE", `/kms/keys/${id}`);
}
export async function rotateKMSKey(id) {
    return call("POST", `/kms/keys/${id}/rotate`);
}
// ===== Catalog =====
export async function getCatalogStats() {
    return call("GET", "/catalog/stats");
}
export async function getCatalogConfig() {
    return call("GET", "/catalog/config");
}
export async function updateCatalogConfig(body) {
    return call("PUT", "/catalog/config", body);
}
export async function enableCatalog() {
    return call("POST", "/catalog/enable");
}
export async function disableCatalog() {
    return call("POST", "/catalog/disable");
}
export async function searchObjects(params) {
    return call("GET", "/catalog/objects/search", undefined, params);
}
export async function searchBySQL(query) {
    return call("GET", "/catalog/search", undefined, { query });
}
export async function vectorSearch(body) {
    return call("POST", "/catalog/search/vector", body);
}
export async function getObjectDetail(bucketId, objectName, version) {
    const params = {
        bucket_id: bucketId,
        object_name: objectName,
    };
    if (version)
        params.version = version;
    return call("GET", "/catalog/objects/detail", undefined, params);
}
export async function testCatalogConnection() {
    return call("POST", "/catalog/test-connection");
}
export async function testCatalogEmbedding() {
    return call("POST", "/catalog/test-embedding");
}
export async function listIcebergCatalogs() {
    return call("GET", "/iceberg/admin/catalogs");
}
export async function getIcebergCatalog(name) {
    return call("GET", `/iceberg/admin/catalogs/${encodeURIComponent(name)}`);
}
export async function createIcebergCatalog(body) {
    return call("POST", "/iceberg/admin/catalogs", body);
}
export async function deleteIcebergCatalog(name) {
    return call("DELETE", `/iceberg/admin/catalogs/${encodeURIComponent(name)}`);
}
export async function getIcebergNamespaces(catalog) {
    const q = catalog ? `?catalog=${encodeURIComponent(catalog)}` : "";
    return call("GET", `/iceberg/admin/namespaces${q}`);
}
export async function getIcebergTables(namespace, catalog) {
    const c = catalog ? `&catalog=${encodeURIComponent(catalog)}` : "";
    return call("GET", `/iceberg/admin/tables?namespace=${encodeURIComponent(namespace)}${c}`);
}
export async function getIcebergSchema(namespace, table, catalog) {
    const c = catalog ? `&catalog=${encodeURIComponent(catalog)}` : "";
    return call("GET", `/iceberg/admin/tables/${encodeURIComponent(table)}/schema?namespace=${encodeURIComponent(namespace)}${c}`);
}
export async function getIcebergSnapshots(namespace, table, catalog) {
    const c = catalog ? `&catalog=${encodeURIComponent(catalog)}` : "";
    return call("GET", `/iceberg/admin/tables/${encodeURIComponent(table)}/snapshots?namespace=${encodeURIComponent(namespace)}${c}`);
}
export async function getIcebergStorageUsage(namespace, catalog) {
    const parts = [];
    if (namespace)
        parts.push(`namespace=${encodeURIComponent(namespace)}`);
    if (catalog)
        parts.push(`catalog=${encodeURIComponent(catalog)}`);
    const q = parts.length ? `?${parts.join("&")}` : "";
    return call("GET", `/iceberg/admin/storage-usage${q}`);
}
export async function getIcebergConfig() {
    return call("GET", "/iceberg/admin/config");
}
export async function putIcebergConfig(body) {
    return call("PUT", "/iceberg/admin/config", body);
}
export async function getIcebergStatus() {
    return call("GET", "/iceberg/admin/status");
}
export async function enableIceberg() {
    return call("POST", "/iceberg/admin/enable");
}
export async function disableIceberg() {
    return call("POST", "/iceberg/admin/disable");
}
export async function getIcebergTable(namespace, table, catalog) {
    const c = catalog && catalog !== "default" ? `&catalog=${encodeURIComponent(catalog)}` : "";
    return call("GET", `/iceberg/admin/tables/${encodeURIComponent(table)}?namespace=${encodeURIComponent(namespace)}${c}`);
}
export async function getIcebergCommits(namespace, table, catalog) {
    const c = catalog && catalog !== "default" ? `&catalog=${encodeURIComponent(catalog)}` : "";
    return call("GET", `/iceberg/admin/tables/${encodeURIComponent(table)}/commits?namespace=${encodeURIComponent(namespace)}${c}`);
}
export async function expireIcebergSnapshots(namespace, table, opts) {
    const c = opts.catalog && opts.catalog !== "default" ? `&catalog=${encodeURIComponent(opts.catalog)}` : "";
    return call("POST", `/iceberg/admin/tables/${encodeURIComponent(table)}/expire?namespace=${encodeURIComponent(namespace)}${c}`, { retain_last: opts.retain_last ?? 1, dry_run: opts.dry_run ?? true });
}
export async function removeIcebergOrphanFiles(namespace, table, opts) {
    const c = opts.catalog && opts.catalog !== "default" ? `&catalog=${encodeURIComponent(opts.catalog)}` : "";
    return call("POST", `/iceberg/admin/tables/${encodeURIComponent(table)}/orphan?namespace=${encodeURIComponent(namespace)}${c}`, { dry_run: opts.dry_run ?? true });
}
export async function compactIcebergMetadata(namespace, table, opts) {
    const c = opts.catalog && opts.catalog !== "default" ? `&catalog=${encodeURIComponent(opts.catalog)}` : "";
    return call("POST", `/iceberg/admin/tables/${encodeURIComponent(table)}/compact-metadata?namespace=${encodeURIComponent(namespace)}${c}`, { dry_run: opts.dry_run ?? true });
}
export async function queryIcebergTable(sql, namespace, table, opts) {
    const c = opts.catalog && opts.catalog !== "default" ? `&catalog=${encodeURIComponent(opts.catalog)}` : "";
    return call("POST", `/iceberg/admin/query${c}`, { sql, namespace, table, limit: opts.limit ?? 100 });
}
export async function getIAMAccountSummary(account) {
    return call("GET", "/iam/account-summary", undefined, { account });
}
export async function listIAMUsers(params) {
    return call("GET", "/iam/users", undefined, params);
}
export async function getIAMUser(userId) {
    return call("GET", `/iam/users/${userId}`);
}
export async function createIAMUser(body) {
    return call("POST", "/iam/users", body);
}
export async function updateIAMUser(userId, body) {
    return call("PUT", `/iam/users/${userId}`, body);
}
export async function deleteIAMUser(userId) {
    await callRaw("DELETE", `/iam/users/${userId}`);
}
export async function listIAMAccessKeys(userId) {
    return call("GET", `/iam/users/${userId}/access-keys`);
}
export async function createIAMAccessKey(userId) {
    return call("POST", `/iam/users/${userId}/access-keys`, {});
}
export async function updateIAMAccessKeyStatus(userId, keyId, status) {
    await callRaw("PUT", `/iam/users/${userId}/access-keys/${keyId}`, { status });
}
export async function deleteIAMAccessKey(userId, keyId) {
    await callRaw("DELETE", `/iam/users/${userId}/access-keys/${keyId}`);
}
export async function listIAMUserInlinePolicies(userId) {
    return call("GET", `/iam/users/${userId}/policies`);
}
export async function putIAMUserInlinePolicy(userId, name, document) {
    await callRaw("PUT", `/iam/users/${userId}/policies/${name}`, { document });
}
export async function deleteIAMUserInlinePolicy(userId, name) {
    await callRaw("DELETE", `/iam/users/${userId}/policies/${name}`);
}
export async function listIAMUserAttachedPolicies(userId) {
    return call("GET", `/iam/users/${userId}/attached-policies`);
}
export async function attachIAMUserPolicy(userId, policyArn) {
    await callRaw("POST", `/iam/users/${userId}/attached-policies`, { policyArn });
}
export async function detachIAMUserPolicy(userId, policyArn) {
    await callRaw("DELETE", `/iam/users/${userId}/attached-policies`, undefined, { policyArn });
}
export async function listIAMUserGroups(userId) {
    return call("GET", `/iam/users/${userId}/groups`);
}
export async function addIAMUserToGroup(userId, groupId) {
    await callRaw("POST", `/iam/users/${userId}/groups/${groupId}`, {});
}
export async function removeIAMUserFromGroup(userId, groupId) {
    await callRaw("DELETE", `/iam/users/${userId}/groups/${groupId}`);
}
export async function listIAMGroups(params) {
    return call("GET", "/iam/groups", undefined, params);
}
export async function getIAMGroup(groupId) {
    return call("GET", `/iam/groups/${groupId}`);
}
export async function createIAMGroup(body) {
    return call("POST", "/iam/groups", body);
}
export async function deleteIAMGroup(groupId) {
    await callRaw("DELETE", `/iam/groups/${groupId}`);
}
export async function listIAMGroupMembers(groupId) {
    return call("GET", `/iam/groups/${groupId}/users`);
}
export async function addIAMGroupMember(groupId, userId) {
    await callRaw("POST", `/iam/groups/${groupId}/users/${userId}`, {});
}
export async function removeIAMGroupMember(groupId, userId) {
    await callRaw("DELETE", `/iam/groups/${groupId}/users/${userId}`);
}
export async function listIAMGroupInlinePolicies(groupId) {
    return call("GET", `/iam/groups/${groupId}/policies`);
}
export async function putIAMGroupInlinePolicy(groupId, name, document) {
    await callRaw("PUT", `/iam/groups/${groupId}/policies/${name}`, { document });
}
export async function deleteIAMGroupInlinePolicy(groupId, name) {
    await callRaw("DELETE", `/iam/groups/${groupId}/policies/${name}`);
}
export async function listIAMGroupAttachedPolicies(groupId) {
    return call("GET", `/iam/groups/${groupId}/attached-policies`);
}
export async function attachIAMGroupPolicy(groupId, policyArn) {
    await callRaw("POST", `/iam/groups/${groupId}/attached-policies`, { policyArn });
}
export async function detachIAMGroupPolicy(groupId, policyArn) {
    await callRaw("DELETE", `/iam/groups/${groupId}/attached-policies`, undefined, { policyArn });
}
export async function listIAMManagedPolicies(params) {
    return call("GET", "/iam/policies", undefined, params);
}
export async function getIAMManagedPolicy(policyId) {
    return call("GET", `/iam/policies/${policyId}`);
}
export async function listIAMRoles(params) {
    return call("GET", "/iam/roles", undefined, params);
}
export async function getIAMRole(roleId) {
    return call("GET", `/iam/roles/${roleId}`);
}
export async function createIAMRole(body) {
    return call("POST", "/iam/roles", body);
}
export async function deleteIAMRole(roleId) {
    await callRaw("DELETE", `/iam/roles/${roleId}`);
}
export async function getIAMRoleTrustPolicy(roleId) {
    return call("GET", `/iam/roles/${roleId}/trust-policy`);
}
export async function updateIAMRoleTrustPolicy(roleId, document) {
    await callRaw("PUT", `/iam/roles/${roleId}/trust-policy`, { document });
}
export async function listIAMRoleInlinePolicies(roleId) {
    return call("GET", `/iam/roles/${roleId}/policies`);
}
export async function putIAMRoleInlinePolicy(roleId, name, document) {
    await callRaw("PUT", `/iam/roles/${roleId}/policies/${name}`, { document });
}
export async function deleteIAMRoleInlinePolicy(roleId, name) {
    await callRaw("DELETE", `/iam/roles/${roleId}/policies/${name}`);
}
export async function listIAMRoleAttachedPolicies(roleId) {
    return call("GET", `/iam/roles/${roleId}/attached-policies`);
}
export async function attachIAMRolePolicy(roleId, policyArn) {
    await callRaw("POST", `/iam/roles/${roleId}/attached-policies`, { policyArn });
}
export async function detachIAMRolePolicy(roleId, policyArn) {
    await callRaw("DELETE", `/iam/roles/${roleId}/attached-policies`, undefined, { policyArn });
}
export async function listIAMOIDCProviders() {
    return call("GET", "/iam/oidc-providers");
}
export async function createIAMOIDCProvider(body) {
    return call("POST", "/iam/oidc-providers", body);
}
export async function deleteIAMOIDCProvider(providerId) {
    await callRaw("DELETE", `/iam/oidc-providers/${providerId}`);
}
