#!/usr/bin/env node
/**
 * StoreFS MCP Server
 *
 * Provides Claude Code (and other MCP clients) with management tools for
 * StoreFS distributed S3 storage clusters.
 *
 * Admin API runs on port 7946 (gossip+HTTP multiplexed).
 * S3 REST API runs on port 8901.
 *
 * Usage:
 *   STOREFS_ADMIN_URL=http://127.0.0.1:7946 \
 *   STOREFS_S3_URL=http://127.0.0.1:8901 \
 *   npx tsx src/index.ts              # dev mode
 *
 *   node dist/index.js                # after npm run build
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { registerSystemTools } from "./tools/system.js";
import { registerUserTools } from "./tools/user.js";
import { registerPolicyTools } from "./tools/policy.js";
import { registerBucketTools } from "./tools/bucket.js";
import { registerObjectTools } from "./tools/object.js";
import { registerS3Tools } from "./tools/s3-operations.js";
import { registerTaskTools } from "./tools/task.js";
import { registerNotificationTools } from "./tools/notification.js";
import { registerKMSTools } from "./tools/kms.js";
import { registerCatalogTools } from "./tools/catalog.js";
import { registerIcebergTools } from "./tools/iceberg.js";
import { registerIamTools } from "./tools/iam.js";
const server = new McpServer({
    name: "storefs-mcp",
    version: "0.6.0",
    description: "StoreFS distributed S3 storage management — manage users, buckets, policies, objects, tasks, and perform S3 data operations.",
});
// Register all tool groups
registerSystemTools(server);
registerUserTools(server);
registerPolicyTools(server);
registerBucketTools(server);
registerObjectTools(server);
registerS3Tools(server);
registerTaskTools(server);
registerNotificationTools(server);
registerKMSTools(server);
registerCatalogTools(server);
registerIcebergTools(server);
registerIamTools(server);
// Start
const transport = new StdioServerTransport();
await server.connect(transport);
