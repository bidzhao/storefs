/**
 * Admin API authentication state management.
 * Stores the auth token obtained from /auth/login and provides
 * the Authorization header for subsequent API calls.
 */
import { tr } from "../i18n.js";
let authHeader = null;
let currentUser = null;
let authMethod = null;
/** Track pending MFA sessions: username -> tempToken */
const pendingMFASessions = new Map();
/** Track MFA verification failures per username */
const mfaFailureCounts = new Map();
const MFA_MAX_ATTEMPTS = 3;
/** Store login result for subsequent requests */
export function setAuth(token, user) {
    authHeader = `Bearer ${token}`;
    currentUser = {
        id: user.id,
        name: user.name,
        role: user.role,
        groupId: user.groupId,
        groupName: user.groupName ?? "",
    };
    authMethod = "password";
}
/** Store PAT-based authentication */
export function setPATAuth(token, user) {
    authHeader = `Bearer ${token}`;
    currentUser = {
        id: user.id,
        name: user.name,
        role: user.role,
        groupId: user.groupId,
        groupName: user.groupName ?? "",
    };
    authMethod = "pat";
}
/** Update the stored token (for sliding renewal from X-New-Access-Token header) */
export function updateToken(token) {
    if (authHeader) {
        authHeader = `Bearer ${token}`;
    }
}
/** Clear auth state (logout) */
export function clearAuth() {
    authHeader = null;
    currentUser = null;
    authMethod = null;
}
/** Get the Authorization header value */
export function getAuthHeader() {
    if (!authHeader) {
        throw new Error(tr("not_authenticated"));
    }
    return authHeader;
}
/** Check if authenticated */
export function isAuthenticated() {
    return authHeader !== null;
}
/** Get current user info */
export function getCurrentUser() {
    return currentUser;
}
/** Check if authenticated via PAT */
export function isPATAuthenticated() {
    return authMethod === "pat";
}
/** Store a pending MFA tempToken for a user */
export function setPendingMFA(username, tempToken) {
    pendingMFASessions.set(username, tempToken);
}
/** Get the stored tempToken for a pending MFA session */
export function getPendingMFA(username) {
    return pendingMFASessions.get(username);
}
/** Clear a pending MFA session (on success or restart) */
export function clearPendingMFA(username) {
    pendingMFASessions.delete(username);
    mfaFailureCounts.delete(username);
}
/** Check if a user has a pending MFA session */
export function hasPendingMFA(username) {
    return pendingMFASessions.has(username);
}
/** Get remaining MFA attempts for a user */
export function getMFARemainingAttempts(username) {
    return MFA_MAX_ATTEMPTS - (mfaFailureCounts.get(username) ?? 0);
}
/** Record an MFA verification failure. Returns true if max attempts exceeded (locked out). */
export function recordMFAFailure(username) {
    const count = (mfaFailureCounts.get(username) ?? 0) + 1;
    mfaFailureCounts.set(username, count);
    if (count >= MFA_MAX_ATTEMPTS) {
        pendingMFASessions.delete(username);
        mfaFailureCounts.delete(username);
        return true;
    }
    return false;
}
/** Reset MFA failure counter for a user (on success or explicit restart) */
export function resetMFAFailures(username) {
    mfaFailureCounts.delete(username);
}
