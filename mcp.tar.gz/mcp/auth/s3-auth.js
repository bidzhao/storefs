/**
 * S3 Signature V4 signing using @smithy/signature-v4.
 */
import { SignatureV4 } from "@smithy/signature-v4";
import { Sha256 } from "@aws-crypto/sha256-js";
/** Compute the byte length of a request body. */
function bodyByteLength(body) {
    if (typeof body === "string")
        return new TextEncoder().encode(body).byteLength;
    return body.byteLength;
}
/** Build a signed S3 request. Returns a Headers object ready to use with fetch(). */
export async function signS3Request(baseUrl, req, creds, region = "us-east-1") {
    const url = new URL(req.path, baseUrl);
    // Build signing headers:
    //  1) x-amz-content-sha256=UNSIGNED-PAYLOAD  → server always defaults to this
    //  2) content-length  (for PUT with body)    → Go SDK v4 signer always includes it
    //  3) content-type default for string body  → fetch() would add text/plain;charset=UTF-8
    //  4) caller-supplied extra headers
    const signingHeaders = {
        host: url.host,
        "x-amz-content-sha256": "UNSIGNED-PAYLOAD",
    };
    if (req.body != null) {
        const len = bodyByteLength(req.body);
        if (len > 0)
            signingHeaders["content-length"] = String(len);
    }
    // Apply caller's headers first (they take precedence over defaults)
    if (req.headers)
        Object.assign(signingHeaders, req.headers);
    // Default content-type for string body if none provided (matches fetch() behavior)
    if (req.body != null && typeof req.body === "string" && !signingHeaders["content-type"]) {
        signingHeaders["content-type"] = "text/plain;charset=UTF-8";
    }
    const signer = new SignatureV4({
        credentials: {
            accessKeyId: creds.accessKeyId,
            secretAccessKey: creds.secretAccessKey,
        },
        region,
        service: "s3",
        sha256: Sha256,
        // Server uses DisableURIPathEscaping=true  → use path as-is, don't double-encode
        uriEscapePath: false,
    });
    const signed = await signer.sign({
        method: req.method,
        protocol: url.protocol.slice(0, -1),
        hostname: url.hostname,
        port: url.port ? parseInt(url.port) : undefined,
        path: url.pathname,
        query: Object.fromEntries(url.searchParams.entries()),
        headers: signingHeaders,
        body: req.body ?? "",
    });
    // Flatten headers (SignedHeaders may be an array)
    const headers = {};
    for (const [k, v] of Object.entries(signed.headers)) {
        headers[k] = Array.isArray(v) ? v.join(", ") : String(v ?? "");
    }
    return { url: url.toString(), headers };
}
