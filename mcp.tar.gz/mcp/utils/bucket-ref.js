import { z } from "zod";
import { td } from "../i18n.js";
/**
 * Optional `bucketName` parameter added alongside `bucketId` on bucket-addressed
 * tools. The admin API accepts a bucket name in the same path slot as the
 * numeric ID (`/api/buckets/{id-or-name}`), so callers can pass a name instead
 * of looking up the ID first.
 */
export function bucketNameParam() {
    return { bucketName: z.string().optional().describe(td("storefs__bucketName")) };
}
/**
 * Resolves the bucket reference to pass into the admin API path. `bucketId`
 * takes precedence; falls back to `bucketName` when the ID is absent.
 */
export function bucketRef(v) {
    return v.bucketId ?? v.bucketName ?? "";
}
